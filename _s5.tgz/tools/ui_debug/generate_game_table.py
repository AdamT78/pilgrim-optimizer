"""Write the generated game table layout page.

This page is composition only: it arranges renderers that already exist into the four-player table
the physical game reads as -- the shared boards across the top, the seats in a row underneath. The
renderers keep owning what each component looks like; nothing here draws geometry of its own.

    alms table      piety track     map
    2P 3P 4P 1..6   duty wheel
    P1 A+ A- P+ P-
    P1 src dst Move

    red seat        seat            seat            seat

The stage is left-aligned, so the two rows start on the same vertical and the red seat comes out
under the alms table. Under that table sits one compact four-row control stack: the table's own
buttons, then Alms/Piety discs and resources, then winners and buildings, then a seat's cubes and
where they walk -- around its own board, and out to the City in the middle of the wheel. These
controls are local page state only: no GameState, no rules, and no scaling solve changes.

ONE SHARED SCALE
Each renderer draws in its own units and was authored as its own standalone page, so handing
every panel a width by eye makes the same wooden cube come out a different size on each board.
The fix is to stop choosing panel widths. One physical reference -- a cube -- is measured in each
board's own units, and every display width falls out of it:

    display width = --cube * (cropped viewBox width / cube size in that board's units)

so a single `--cube` in the stylesheet drives the whole table and every board stays in proportion
when it changes. Two boards draw no cube, so each is anchored on a piece it does share: the piety
track on the disc it shares with the alms table, and the map on the board hexagon the duty wheel's
was derived from.

The duty wheel is the exception. It is given whatever height the row has left rather than a width of
its own, so it draws a smaller cube than `--cube` names, and a seat -- which has to match it piece
for piece -- is sized against the wheel rather than against the cube. That is what lets a player
board be any shape it likes: the seats used to be stacked to the wheel's height instead, which made
a board's proportions decide the scale it was drawn at here.

The two rows then compete differently. Each asks for the window's width on its own, since neither is
inside the other, while for height they take the window one after the other. Nothing is scaled to
fit: there is one cube and every panel is a fixed multiple of it, so seating four rather than two
shows up as a smaller cube for the whole table rather than as a board drawn at a size of its own.

CROPPED, NOT REDRAWN
Those same standalone pages put a heading, a subtitle and a backdrop inside the viewBox -- nearly
half of the duty wheel's box is page furniture -- which would otherwise be paid for in the middle
of a table. Each fragment's viewBox is therefore pointed at its own panel instead. Nothing is
deleted: the extra elements are simply outside the view, and no renderer changes.

Nothing here reads or writes `GameState`, picks legal actions, or applies any rule. The controls
below the Alms Table move only this page's own SVG elements and state; `game_setup.html` remains
the full control-heavy debug sandbox.

Run from the repo root:

    python3 tools/ui_debug/generate_game_table.py
"""

from __future__ import annotations

import json
import re
import sys
from html import escape
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from tools.ui_debug.generate_game_setup import (  # noqa: E402
    ABBEY_PLACE_ID,
    DEFAULT_START_ROLL,
    EDGE_HEX_PATH,
    START_HEX_BY_ROLL,
    acolyte_places,
    available_setup_buildings,
    building_ownership_state,
    hex_centers,
    render_building_content_defs,
    render_setup_map_svg,
    setup_placements,
)
from tools.ui_debug.render_alms_table import (
    RANK_FIRST,
    alms_position_target,
    alms_rules,
    load_alms_config,
    load_alms_table_layout,
    placeholder_slots,
    render_alms_table_svg,
)
from tools.ui_debug.render_alms_table import (
    players_of as alms_players,
)
from tools.ui_debug.render_buildings import load_building_catalog  # noqa: E402
from tools.ui_debug.render_donated_buildings import (  # noqa: E402
    load_donated_building_tiles,
)
from tools.ui_debug.render_duty_wheel import (  # noqa: E402
    CITY_SPOKE_REVERSAL_ARROWS,
    CITY_STACK_HEIGHT,
    CORNUCOPIA_TOKEN,
    duty_setups,
    load_duty_wheel_layout,
    merchant_path,
    render_duty_wheel_svg,
)
from tools.ui_debug.render_map import load_map_layout  # noqa: E402
from tools.ui_debug.render_piety_track_v2 import (  # noqa: E402
    load_piety_config,
    load_piety_track_v2_layout,
    position_center_x,
    render_piety_track_v2_svg,
    seated_players,
)
from tools.ui_debug.render_pilgrimage_sites import load_pilgrimage_sites  # noqa: E402
from tools.ui_debug.render_player_boards_v2 import (  # noqa: E402  # noqa: E402
    ROLE_ACOLYTE_LIMIT,
    default_player_board_v2_state,
    load_player_boards_v2_layout,
    player_by_id,
    render_player_board_v2_svg,
    resource_choice_styles,
    token_slot_count,
)
from tools.ui_debug.render_table_layout import (  # noqa: E402
    PIETY_VARIANT_ID,
    SEATED_PLAYERS,
    board_measurements,
    crop_svg,
    duty_hexagon,
    regularise_duty_hexagon,
    render_table_stage,
    solve_table_scale,
    table_layout_styles,
    table_stacking_styles,
)

GENERATED_DIRNAME = "generated"
OUTPUT_FILENAME = "game_table.html"

# The tab only. The page itself carries no text: it opens straight into the table, so that what
# is being judged is the arrangement rather than a page about the arrangement.
PAGE_TITLE = "Pilgrim — Game Table"

# Four seats are drawn in the layout, so the 3-4 player track. The 2 player variant stays on the
# standalone v2 page.

# Every seat the layout describes, in the order they sit along the row. The 2P/3P/4P control only
# toggles which of these fixed seats are visible; it does not reseat anyone or ask the scale to
# recompute.

# --- page chrome, in px ----------------------------------------------------------------------
# The gap between panels, between the two rows, and between the player boards.

# The window the scale is solved against. `--cube` itself stays responsive; this is only the size
# at which the crop margins are read off, and they barely move with it.

# The seats stand in one row of four under the main row, so the block is as wide as four boards
# and as tall as one. Every seat is drawn whatever the player count is; the count only decides
# which of them are visible, so that nothing moves when it changes.

# The player counts the control bar offers, and the count it opens on.
PLAYER_COUNTS = (2, 3, 4)
DEFAULT_PLAYER_COUNT = 4

# Who holds the first player marker when the table opens. Turn order is decided on the Piety Track
# -- highest piety takes the marker -- and every disc starts on 0, so the tie resolves to the first
# board: seat 1, red. It falls back here whenever the holder's seat leaves the table, because the
# marker is always with someone. Nothing here makes the holder the first player; this PR moves a
# seal and models no turn order at all.
FIRST_PLAYER_SEAT_AT_START = 1

# The turn flow's own colours. The board rings the seat whose turn it is, and the space that seat
# starts from, in that seat's own colour, and lights the ways out of it in a green dark enough to
# read against the ground the arrows are drawn on. The fallback is only what the stylesheet opens
# with; the page sets the variable from the seat itself.
ACTIVE_PLAYER_FALLBACK = "#C94C4C"
TURN_BRANCH_GREEN = "#1E7A34"
TURN_BRANCH_EDGE = "#0C3D1A"
TURN_DIMMED_OPACITY = "0.4"

# The setup rolls and players the compact controls offer.
SETUP_ROLLS = tuple(sorted(START_HEX_BY_ROLL))
DEFAULT_CONTROL_PLAYER_SEAT = 1

# What each seat has in the City to sow out before the first turn. The engine's own setup deals the
# same five -- `_starting_player_state` in `pilgrim/setup/generator.py` -- but this page reads
# nothing from it: the number is written down here so the board can be dealt without asking.
SETUP_CITY_CUBES = 5

# What a resource's step buttons are called. The board writes the names out in full beside its
# icons; a control row this tight has room for two letters, so the buttons say `Wh+` where the
# board says `Wheat`. Keyed by the layout's own resource ids, so a resource the board stops
# drawing takes its buttons with it rather than leaving a pair that steps nothing.
RESOURCE_ABBREVIATIONS = {"wheat": "Wh", "stone": "St", "silver": "Si"}

# A resource cannot go below nothing. There is no ceiling: what a player may actually hold is a
# rule, and no rule is applied on this page.
RESOURCE_FLOOR = 0

# Dead canvas left around a player board, in its own units. Every other board's margin is solved
# to match whatever this comes out as on screen.

# Somewhere to start the fixed point below; none of these survives the first few passes.

# The duty wheel draws its hexagon with this stroke, in the units of its own board group.



def default_output_path() -> Path:
    return Path(__file__).resolve().parent / GENERATED_DIRNAME / OUTPUT_FILENAME


def seat_numbers_by_player() -> dict[str, int]:
    """Seat index for each seated player id: red is 1, then yellow, blue, white."""
    return {player_id: index for index, player_id in enumerate(SEATED_PLAYERS, start=1)}


def visible_seats_by_count() -> dict[str, list[int]]:
    """Which seat numbers stay visible at each player count.

    Seats are fixed slots. Lower counts only drop the later ones, so nothing moves.
    """
    return {str(count): list(range(1, count + 1)) for count in PLAYER_COUNTS}


def tag_player_discs(fragment: str) -> str:
    """Stamp each rendered disc with the seat number the player-count control uses.

    The standalone renderers already tag discs with `data-player`; this only adds the seat index
    the composed page needs, without changing what the standalone pages emit.
    """
    tagged = fragment
    for player_id, seat in seat_numbers_by_player().items():
        needle = f'data-player-disc="true" data-player="{player_id}"'
        if needle not in tagged:
            raise ValueError(f"no disc for {player_id} to tag with seat {seat}")
        tagged = tagged.replace(
            needle,
            f'data-player-disc="{seat}" data-player-seat="{seat}" data-player="{player_id}"',
            1,
        )
    return tagged


def tag_resource_readouts(fragment: str, board_layout: dict) -> str:
    """Stamp each resource amount with the id of the resource it counts.

    The renderer already names the readout's group; the amount inside it is the only text there,
    and this is what lets the control row find it without reaching through the group's shape.
    Done here rather than in the renderer so the standalone board page is unchanged.
    """
    tagged = fragment
    for resource in board_layout["resources"]:
        resource_id = resource["id"]
        group = re.compile(
            rf'(<g data-resource="{re.escape(resource_id)}"[^>]*>.*?)<text ',
            re.DOTALL,
        )
        tagged, count = group.subn(
            rf'\1<text data-player-resource="{resource_id}" ', tagged, count=1
        )
        if not count:
            raise ValueError(f"no {resource_id} readout to tag on the player board")
    return tagged


def _options(choices: list[tuple[str, str]], selected: str) -> str:
    return "".join(
        f'<option value="{value}"{" selected" if value == selected else ""}>{label}</option>'
        for value, label in choices
    )


def _seat_colour_options(board_layout: dict) -> list[tuple[str, str]]:
    colours = {player["id"]: player["color"].capitalize() for player in board_layout["players"]}
    return [
        (str(seat), colours[player_id]) for seat, player_id in enumerate(SEATED_PLAYERS, start=1)
    ]


def _control_player_options(board_layout: dict) -> list[tuple[str, str]]:
    return _seat_colour_options(board_layout)


def _first_player_options(board_layout: dict) -> list[tuple[str, str]]:
    """The seats the marker can sit with, and no other entry.

    There is no `nobody` here on purpose: the marker always sits with someone. The renderer will
    draw a panel with no marker on it, which is what leaves the standalone pages alone, but that is
    a rendering default and not a state this table can be in.
    """
    return _seat_colour_options(board_layout)


def _resource_buttons(board_layout: dict) -> str:
    """A pair of steps per resource, in the order the board draws its readouts."""
    return "".join(
        f'<button type="button" data-resource-button="{resource["id"]}:{sign}">'
        f"{RESOURCE_ABBREVIATIONS[resource['id']]}{sign}</button>"
        for resource in board_layout["resources"]
        for sign in ("+", "-")
    )


def _building_options(placements: list[dict]) -> list[tuple[str, str]]:
    """Every building still for sale, keyed by the setup slot it stands on.

    The slot is the key rather than the hex, so a setup roll can move a building around the map
    without changing which entry in this list it is.
    """
    return [
        (str(building["setupSlot"]), escape(building["label"]))
        for building in available_setup_buildings(placements)
    ]


def _building_slot_options(board_layout: dict) -> list[tuple[str, str]]:
    """The board's building slots, by number. The row is tight, so they are numbered, not named."""
    return [
        (str(number), str(number))
        for number in range(1, int(board_layout["building_slot_count"]) + 1)
    ]


def render_compact_controls(board_layout: dict, placements: list[dict]) -> str:
    """Four compact rows under the Alms Table, with no labels or help text."""
    count_buttons = "".join(
        f'<button type="button" data-player-count-button="{count}"'
        f' aria-pressed="{"true" if count == DEFAULT_PLAYER_COUNT else "false"}">{count}P</button>'
        for count in PLAYER_COUNTS
    )
    setup_buttons = "".join(
        f'<button type="button" data-setup-roll-button="{roll}"'
        f' aria-pressed="{"true" if roll == DEFAULT_START_ROLL else "false"}">{roll}</button>'
        for roll in SETUP_ROLLS
    )
    players = _control_player_options(board_layout)
    places = acolyte_places(board_layout)
    first_role = places[1][0] if len(places) > 1 else places[0][0]
    buildings = _building_options(placements)
    slots = _building_slot_options(board_layout)
    return (
        '<div class="table-controls" data-component="game-table-controls">'
        '<div class="control-row" data-controls-row="1">'
        f"{count_buttons}{setup_buttons}"
        '<button type="button" data-duty-randomize-button="true">R</button>'
        '<button type="button" data-setup-mode-button="true" aria-pressed="false">Setup</button>'
        '<button type="button" data-ship-advance="true">S+</button>'
        '<button type="button" data-merchant-advance-button="true">M+</button>'
        '<select id="first-player-seat" data-first-player-select="true">'
        f"{_options(_first_player_options(board_layout), str(FIRST_PLAYER_SEAT_AT_START))}</select>"
        "</div>"
        '<div class="control-row" data-controls-row="2">'
        f'<select id="disc-player-seat">{_options(players, str(DEFAULT_CONTROL_PLAYER_SEAT))}</select>'
        '<button type="button" data-disc-track="alms" data-disc-delta="1">A+</button>'
        '<button type="button" data-disc-track="alms" data-disc-delta="-1">A-</button>'
        '<button type="button" data-disc-track="piety" data-disc-delta="1">P+</button>'
        '<button type="button" data-disc-track="piety" data-disc-delta="-1">P-</button>'
        f"{_resource_buttons(board_layout)}"
        "</div>"
        '<div class="control-row" data-controls-row="3">'
        '<select id="alms-winner-player-seat" data-alms-winner-player-select="true">'
        f"{_options(players, str(DEFAULT_CONTROL_PLAYER_SEAT))}</select>"
        '<button type="button" data-alms-winner-button="add">AT+</button>'
        '<button type="button" data-alms-winner-button="reset">ATr</button>'
        '<select id="buy-building" data-building-buy-select="true">'
        f"{_options(buildings, buildings[0][0] if buildings else '')}</select>"
        '<button type="button" data-building-buy-button="true">Buy</button>'
        '<select id="donate-building-slot" data-building-donate-slot-select="true">'
        f"{_options(slots, slots[0][0])}</select>"
        '<button type="button" data-building-donate-button="true">Donate</button>'
        "</div>"
        '<div class="control-row" data-controls-row="4">'
        f'<select id="acolyte-player-seat">{_options(players, str(DEFAULT_CONTROL_PLAYER_SEAT))}</select>'
        f'<select id="acolyte-source">{_options(places, ABBEY_PLACE_ID)}</select>'
        f'<select id="acolyte-target">{_options(places, first_role)}</select>'
        '<button type="button" id="move-acolyte">Move acolyte</button>'
        '<button type="button" data-serf-to-abbey-button="true">S-&gt;A</button>'
        '<button type="button" data-abbey-to-city-button="true">A-&gt;C</button>'
        '<button type="button" data-village-to-city-button="true">V-&gt;C</button>'
        "</div>"
        "</div>"
    )


def setup_roll_data(map_layout: dict) -> dict:
    centers = hex_centers(map_layout)
    return {
        "edgePath": list(EDGE_HEX_PATH),
        "hexCenters": {label: [round(x, 1), round(y, 1)] for label, (x, y) in centers.items()},
        "startHexByRoll": {str(roll): label for roll, label in START_HEX_BY_ROLL.items()},
        "defaultRoll": DEFAULT_START_ROLL,
    }


def disc_motion_data(alms_layout: dict, alms_config: dict, piety_layout: dict) -> dict:
    seat_by_player = seat_numbers_by_player()
    rules = alms_rules(alms_config)
    alms_max = int(rules.max_position)
    piety_max = int(piety_layout["track"]["position_count"]) - 1
    alms_by_id = {player["id"]: player for player in alms_players(alms_layout)}

    alms_targets = {}
    for player_id, seat in seat_by_player.items():
        player = alms_by_id[player_id]
        alms_targets[str(seat)] = {
            str(position): [
                round(target[0], 1),
                round(target[1], 1),
            ]
            for position in range(alms_max + 1)
            for target in [alms_position_target(alms_layout, rules, player, position)]
        }
        first_target = alms_position_target(alms_layout, rules, player, RANK_FIRST)
        alms_targets[str(seat)][RANK_FIRST] = [round(first_target[0], 1), round(first_target[1], 1)]

    piety_targets = {}
    for player in seated_players(piety_layout, PIETY_VARIANT_ID):
        seat = seat_by_player[player["id"]]
        piety_targets[str(seat)] = {
            str(position): [
                round(position_center_x(piety_layout, position) + player["cx_offset"], 1),
                round(player["cy"], 1),
            ]
            for position in range(piety_max + 1)
        }

    def pair_columns(targets: dict[str, dict[str, list[float]]]) -> dict[str, list[float]]:
        return {
            position: [
                round((targets["1"][position][0] + targets["3"][position][0]) / 2, 1),
                targets["1"][position][1],
                targets["2"][position][1],
            ]
            for position in targets["1"]
        }

    starts = {
        "alms": {
            str(seat): int(alms_layout["starting_position"])
            for seat in range(1, len(SEATED_PLAYERS) + 1)
        },
        "piety": {
            str(seat): int(piety_layout["track"]["disc_position"])
            for seat in range(1, len(SEATED_PLAYERS) + 1)
        },
    }
    return {
        "targets": {"alms": alms_targets, "piety": piety_targets},
        "pair": {"alms": pair_columns(alms_targets), "piety": pair_columns(piety_targets)},
        "initial": starts,
        "max": {"alms": alms_max, "piety": piety_max},
        "first": {"alms": RANK_FIRST},
    }


def resource_control_data(board_layout: dict) -> dict:
    """Every seat's resources, starting from the amounts the board is drawn holding."""
    resources = board_layout["resources"]
    return {
        "ids": [resource["id"] for resource in resources],
        "floor": RESOURCE_FLOOR,
        "state": {
            str(seat): {resource["id"]: int(resource["count"]) for resource in resources}
            for seat in range(1, len(SEATED_PLAYERS) + 1)
        },
    }


def duty_wheel_seating(layout: dict) -> dict:
    """The wheel drawn with this table's seating rather than its own.

    This page seats P1 to P4 in one order everywhere else it counts players -- the boards in the
    row, the discs on both tracks -- so the wheel is reseated to match. Only who sits where
    changes: the neutral column, the geometry, and the standalone wheel page are all untouched.
    """
    seated = dict(layout)
    seated["seats_by_player_count"] = {
        str(count): list(SEATED_PLAYERS[:count]) for count in layout["player_counts"]
    }
    # This table opens on four players, so that is the tally the wheel should open showing.
    seated["default_player_count"] = DEFAULT_PLAYER_COUNT
    return seated


def duty_control_data(layout: dict) -> dict:
    """What the wheel's buttons walk through: its sample setups, the Merchant's ring, and the City.

    The City is the one space cubes arrive at from off the wheel, so the room a column has and the
    number opening in it are both read from the wheel rather than restated here.
    """
    return {
        "setups": duty_setups(layout),
        "merchantPath": merchant_path(layout),
        "merchantStart": layout["merchant_token"]["starts_on"],
        "city": {
            "capacity": CITY_STACK_HEIGHT,
            "opening": int(layout["city_sample_cubes_per_seat"]),
        },
    }


def building_control_data(board_layout: dict, placements: list[dict]) -> dict:
    """Where every building stands before anything is bought: all on the map, no board owns one.

    This is `building_ownership_state` with the players re-keyed to seat numbers, because the
    compact rows pick a seat rather than a player id. The shape is otherwise the setup page's,
    so the buy and donate moves the script makes are the ones `buy_building` and
    `donate_building` already describe in Python.
    """
    ownership = building_ownership_state(board_layout, placements)
    seats = seat_numbers_by_player()
    return {
        "slotCount": int(board_layout["building_slot_count"]),
        "state": {
            "available": ownership["available"],
            "players": {
                str(seat): ownership["players"][player_id]
                for player_id, seat in sorted(seats.items(), key=lambda pair: pair[1])
            },
        },
    }


def season_winner_data(alms_layout: dict, alms_config: dict) -> dict:
    """How many winner sockets the record has, which is what caps the row."""
    return {"slotCount": len(placeholder_slots(alms_layout, alms_rules(alms_config)))}


def acolyte_control_data(board_layout: dict) -> dict:
    default = default_player_board_v2_state(board_layout)
    roles = [role["id"] for role in board_layout["worker_roles"]]
    return {
        "abbeyId": ABBEY_PLACE_ID,
        "abbeyCapacity": token_slot_count(board_layout),
        "roleLimit": ROLE_ACOLYTE_LIMIT,
        "roles": roles,
        "places": [{"id": place_id, "label": label} for place_id, label in acolyte_places(board_layout)],
        "state": {
            str(seat): {
                "playerId": player_id,
                "villageSerfs": int(default["village_serfs"]),
                "abbeyAcolytes": int(default["abbey_acolytes"]),
                "roles": {role: int(default["roles"].get(role, 0)) for role in roles},
            }
            for seat, player_id in enumerate(SEATED_PLAYERS, start=1)
        },
    }


def turn_flow_data(duty_layout: dict) -> dict:
    """Who the turn belongs to, and the colour the board should ring their choices in.

    One seat, because nothing on this page picks an active player yet: the compact rows each name
    a seat of their own for the move they make, and none of them speaks for the turn. The whole
    map is carried anyway, so the seat a turn belongs to becomes a variable rather than a rewrite
    when there is something to set it from.
    """
    fills = {player["id"]: player["fill"] for player in duty_layout["players"]}
    return {
        "seat": DEFAULT_CONTROL_PLAYER_SEAT,
        "colors": {
            str(seat): fills[player_id] for seat, player_id in enumerate(SEATED_PLAYERS, start=1)
        },
    }


def render_turn_flow_script() -> str:
    """The turn flow, as the phases a click moves the wheel between.

        idle -> sow_armed -> sowing -> sow_complete -> duty_selected -> resolution_selected
                                ^         |
                                |         v
                          branch_choice   idle

    Sow arms the nine spaces; clicking one lifts the active seat's cubes there into the counter in
    the corner and the hand starts walking, putting one cube down at each position it comes to. It
    stops at a fork, lights the ways out and waits for one to be clicked; then it walks on. When the
    hand is empty the tiles it reached are offered as the duty to take, and taking one with `Action`
    or `Tithe` sends that seat's cubes there home to the City. `Reset` puts the board back the way
    Sow found it at any point along the way.

    A setup sow is the same walk with a different frame around it: every seat starts with five
    acolytes in the City and puts them out, one seat after another, before the first turn. It
    starts itself, since the City is the only place it could start from -- so `Sow` has nothing to
    ask and stays dark, and the walk stops at the City's fork straight away. And it ends with no
    duty offered, `Action` and `Tithe` dark, and `Confirm` lit to hand the wheel to the next seat.

    What any of it is worth is another matter. Nothing here resolves an action or a tithe, scores
    anything, or reads or writes `GameState`: this is the shape of a turn drawn on a board.

    Everything it moves by is a board position -- `city`, `north`, `north_east` and the rest, as
    `configs/board.json` names them -- read off `data-board-position` and the arrows' own
    `data-from-position` and `data-to-position`. The names printed on the tiles are never consulted,
    because turning the tiles moves a duty to another position and moves no position at all.

    Both halves of it are the same trick, run in opposite directions: a cube is picked up by hiding
    the rect it stands in and put down by showing an empty one, so nothing is ever drawn into or
    cut out of the wheel and Reset can hand the board straight back -- including a City column that
    was only partly standing to begin with.
    """
    return """
  /* --- the turn flow ------------------------------------------------------------------------
     Local UI phases only: nothing below sows a cube, resolves an action, or touches GameState. */
  var turnOverlay = dutyPanel
    ? dutyPanel.querySelector('[data-component="duty-wheel-turn-controls"]')
    : null;
  /* Movement is in board positions -- city, north, north_east and the rest -- and never in the
     names printed on the tiles. Turning the tiles moves a duty to another position; it moves no
     position anywhere, so a flow keyed to the labels would start walking the wrong way round the
     board the first time the tiles were turned. */
  var dutySpaces = dutyPanel ? dutyPanel.querySelectorAll('[data-board-position]') : [];
  var dutyOrnaments = dutyPanel ? dutyPanel.querySelectorAll('[data-ornament-position]') : [];
  var dutyArrows = dutyPanel
    ? dutyPanel.querySelectorAll('[data-from-position][data-to-position]')
    : [];
  /* The middle space, as the one the ring of arrows does not run through: every duty tile has a
     place in that ring and says which, and the City is the space that has none. */
  var cityPosition = null;
  Array.prototype.forEach.call(dutySpaces, function (space) {
    if (!space.hasAttribute('data-duty-ring-index')) {
      cityPosition = space.getAttribute('data-board-position');
    }
  });
  /* The board's directed graph, as the arrows drawn on it: every way out of every position. */
  var outgoingEdgesByPosition = {};
  Array.prototype.forEach.call(dutyArrows, function (arrow) {
    var from = arrow.getAttribute('data-from-position');
    outgoingEdgesByPosition[from] = (outgoingEdgesByPosition[from] || []).concat([arrow]);
  });

  function turnControl(name) {
    return turnOverlay ? turnOverlay.querySelector('[data-turn-control="' + name + '"]') : null;
  }

  /* Enabled is what the plaque looks like, not what it accepts: the handlers ask the phase. */
  function setTurnControlState(name, enabled, active) {
    var control = turnControl(name);
    if (!control) {
      return;
    }
    control.setAttribute('data-turn-control-enabled', enabled ? 'true' : 'false');
    control.setAttribute('data-turn-control-active', active ? 'true' : 'false');
    control.setAttribute('aria-disabled', enabled ? 'false' : 'true');
  }

  /* A setup sow is not a turn: the seat is putting its acolytes out, not taking a duty. So the
     two plaques that do something to a duty stay dark all through it, and `Confirm` -- which in a
     normal turn ends the turn -- is there confirming the sow instead. Either way it is the plaque
     that hands the wheel to the next seat. */
  function refreshTurnControls() {
    var started = state.turn.phase !== 'idle';
    var sown = state.turn.phase === 'sow_complete';
    /* A setup sow starts itself from the City, so `Sow` has nothing to ask and stays dark; and
       `Reset`, which is then the only way back to the start of one, stays lit throughout. */
    var asking = !state.setup.on;
    setTurnControlState('sow', asking, asking && started);
    setTurnControlState('reset', started || state.setup.on, false);
    /* A duty has to be chosen before there is anything to do to it, and once one of the two has
       been pressed the pressed one stays lit to say which it was. */
    ['action', 'tithe'].forEach(function (name) {
      var chosen = !state.setup.on && state.turn.phase === 'duty_selected';
      if (name === 'tithe') {
        /* Taxation brings no token, so there is nothing to take and the plaque says so. */
        if (chosen && !titheTokenAt(state.turn.duty)) {
          chosen = false;
        }
        /* And a Cornucopia keeps it lit until the seat has answered. The press has been taken but
           the turn is not finished with it, and the answer happens on a board in another panel:
           a plaque that went quiet here would be pressed again by anyone watching the wheel. */
        if (state.turn.titheChoice === 'pending') {
          chosen = true;
        }
      }
      setTurnControlState(name, chosen, state.turn.resolution === name);
    });
    /* Confirm accepts a setup sow, and in normal play it ends the turn -- so it lights once there
       is a finished turn to end. A Cornucopia still asking is not one: the press has been taken
       but the seat has not answered, and the wheel says as much by keeping `Tithe` lit. */
    var resolved =
      state.turn.phase === 'resolution_selected' && state.turn.titheChoice !== 'pending';
    setTurnControlState('confirm', state.setup.on ? sown : resolved, false);
  }

  function setTurnPhase(phase) {
    state.turn.phase = phase;
    if (turnOverlay) {
      turnOverlay.setAttribute('data-turn-state', phase);
    }
    refreshTurnControls();
  }

  function setCubesInHand(count) {
    state.turn.cubesInHand = count;
    var counter = turnOverlay ? turnOverlay.querySelector('[data-turn-counter]') : null;
    if (!counter) {
      return;
    }
    counter.setAttribute('data-turn-counter-value', String(count));
    counter.setAttribute('aria-label', 'Cubes in hand: ' + count);
    var label = counter.querySelector('text');
    if (label) {
      label.textContent = '\\u00d7 ' + count;
    }
  }

  function spaceAt(position) {
    return dutyPanel
      ? dutyPanel.querySelector('[data-board-position="' + position + '"]')
      : null;
  }

  /* The trefoil drawn over a space. The ornaments are one layer across the whole board rather
     than part of the spaces, so each says which position it stands over. */
  function ornamentAt(position) {
    return dutyPanel
      ? dutyPanel.querySelector('[data-ornament-position="' + position + '"]')
      : null;
  }

  function seatBoard(seat) {
    return document.querySelector(
      '[data-component="player-board-v2"][data-player-seat="' + seat + '"]');
  }

  function activeSeatElement() {
    return seatBoard(state.activeSeat);
  }

  function playerIdForSeat(seat) {
    var board = seatBoard(seat);
    return board ? board.getAttribute('data-player') : null;
  }

  /* The seats in play, in the order they are dealt to and take their turns. */
  function seatsAtTable() {
    var seats = [];
    for (var seat = 1; seat <= state.count; seat += 1) {
      seats.push(seat);
    }
    return seats;
  }

  /* Which player a seat is, asked of the board that is actually on the table rather than worked
     out here. Seat order and player ids are not the same list -- the first seat is red, and red is
     `player_two` -- so anything pairing them up itself would pair them wrongly. */
  function activePlayerId() {
    return playerIdForSeat(state.activeSeat);
  }

  function activePlayerColor() {
    var board = activeSeatElement();
    return board ? board.getAttribute('data-player-color') : null;
  }

  /* The board whose turn it is says so itself, with the wash of its own colour its renderer left
     hidden along its bottom edge; the same colour rings the space that turn starts from. Nothing
     is restyled and no size is written, so the row's widths and heights do not move: each board is
     told whether it is the one, and the stylesheet does the rest. */
  function updateActiveSeatIndicator() {
    Array.prototype.forEach.call(seatBoards, function (board) {
      var active = Number(board.getAttribute('data-player-seat')) === state.activeSeat;
      board.setAttribute('data-active-seat', active ? 'true' : 'false');
    });
    if (!stage) {
      return;
    }
    stage.setAttribute('data-active-player-seat', String(state.activeSeat));
    stage.setAttribute('data-active-player-color', activePlayerColor() || '');
    stage.style.setProperty('--active-player', TURN.colors[String(state.activeSeat)]);
  }

  function setActiveSeat(seat) {
    state.activeSeat = seat;
    updateActiveSeatIndicator();
  }

  function armStartSpaces(armed) {
    Array.prototype.forEach.call(dutySpaces, function (space) {
      if (armed) {
        space.setAttribute('data-turn-start-candidate', 'true');
      } else {
        space.removeAttribute('data-turn-start-candidate');
      }
    });
  }

  function markStartSpace(position) {
    Array.prototype.forEach.call(dutySpaces, function (space) {
      if (space.getAttribute('data-board-position') === position) {
        space.setAttribute('data-turn-start-selected', 'true');
      } else {
        space.removeAttribute('data-turn-start-selected');
      }
    });
  }

  /* The tally the table is playing: every count has one drawn, and only this one is showing. It
     is looked for inside the space itself, so what the tally happens to be named never matters. */
  function activeTallyForPosition(position) {
    var space = spaceAt(position);
    return space
      ? space.querySelector('[data-cube-tally][data-player-count="' + state.count + '"]')
      : null;
  }

  function visibleCubesForPosition(position) {
    var tally = activeTallyForPosition(position);
    if (!tally) {
      return [];
    }
    return Array.prototype.filter.call(tally.querySelectorAll('rect'), function (cube) {
      return cube.getAttribute('opacity') !== '0';
    });
  }

  /* One seat's column on one space, bottom cube first, which is the order the wheel draws them
     in. Every cube says whose it is, so this is also what keeps the other seats' cubes and the
     neutral column's black ones out of anything a seat does. */
  function columnForPosition(position, playerId) {
    var tally = activeTallyForPosition(position);
    if (!tally) {
      return [];
    }
    return Array.prototype.filter.call(tally.querySelectorAll('rect'), function (cube) {
      return cube.getAttribute('data-player') === playerId;
    });
  }

  /* A hand picks up its own cubes and nothing else: the other seats' cubes, the neutral column's,
     and the slots nobody is standing in -- drawn but hidden, so not visible -- all stay put. */
  function visibleActivePlayerCubesForPosition(position) {
    return columnForPosition(position, activePlayerId()).filter(function (cube) {
      return cube.getAttribute('opacity') !== '0';
    });
  }

  /* Stand a column at a given height, which is how a deal is made: the wheel draws every slot a
     column has room for, so setting one is showing the cubes up to it and hiding the rest. */
  function standColumn(position, playerId, standing) {
    columnForPosition(position, playerId).forEach(function (cube, index) {
      cube.setAttribute('opacity', index < standing ? '1' : '0');
    });
  }

  /* Where the next cube can be put down: the lowest empty slot in the active seat's column there.
     The wheel draws every slot a column has room for and hides the empty ones, so putting a cube
     on a space is turning one of them on rather than drawing into the board. A column with none
     left is a column with no room, which is what stops a sow short. */
  function firstEmptySlotForPosition(position) {
    var playerId = activePlayerId();
    var tally = activeTallyForPosition(position);
    if (!tally) {
      return null;
    }
    return Array.prototype.filter.call(tally.querySelectorAll('rect'), function (cube) {
      return cube.getAttribute('data-player') === playerId
        && cube.getAttribute('opacity') === '0';
    })[0] || null;
  }

  function placeOneCubeAtPosition(position) {
    var slot = firstEmptySlotForPosition(position);
    if (!slot) {
      return false;
    }
    slot.setAttribute('opacity', '1');
    state.turn.sown.push(slot);
    setCubesInHand(state.turn.cubesInHand - 1);
    return true;
  }

  function resetSownCubes() {
    state.turn.sown.forEach(function (slot) {
      slot.setAttribute('opacity', '0');
    });
    state.turn.sown = [];
  }

  /* Taken off the board, not taken away: what each cube was showing is remembered, so putting it
     back cannot stand a seat in a slot it was not standing in. Both the hand that picks cubes up
     to sow them and the recall that sends them home from a duty use this pair. */
  function hideCubes(cubes) {
    return cubes.map(function (cube) {
      var held = { cube: cube, opacity: cube.getAttribute('opacity') };
      cube.setAttribute('opacity', '0');
      return held;
    });
  }

  function restoreCubes(held) {
    held.forEach(function (entry) {
      if (entry.opacity === null) {
        entry.cube.removeAttribute('opacity');
      } else {
        entry.cube.setAttribute('opacity', entry.opacity);
      }
    });
  }

  function hidePickupCubes(cubes) {
    state.turn.pickedUp = hideCubes(cubes);
    setCubesInHand(cubes.length);
  }

  function restorePickupCubes() {
    restoreCubes(state.turn.pickedUp);
    state.turn.pickedUp = [];
  }

  /* Every way out of a position, ring arrows and middle arrows alike, since both carry the pair
     of positions they join. One way out is not a choice, so only a position with more than one
     lights up: on this board that is the City, east and west, and no rule had to be written down
     to say so -- it falls out of the graph, and it keeps falling out of it however the tiles are
     turned. Kogge and Cloisters would add and drop edges here; neither is drawn yet. */
  function branchArrowsFrom(position) {
    return outgoingEdgesByPosition[position] || [];
  }

  function highlightBranchChoices(arrows) {
    arrows.forEach(function (arrow) {
      arrow.setAttribute('data-turn-branch-choice', 'true');
    });
  }

  function clearBranchChoices() {
    Array.prototype.forEach.call(dutyArrows, function (arrow) {
      arrow.removeAttribute('data-turn-branch-choice');
    });
  }

  function armSow() {
    if (state.setup.on || state.turn.phase !== 'idle') {
      return;
    }
    armStartSpaces(true);
    setTurnPhase('sow_armed');
  }

  /* Where the hand stands, and the way it came. */
  function setCurrentPosition(position) {
    state.turn.current = position;
    state.turn.route.push(position);
    if (turnOverlay) {
      turnOverlay.setAttribute('data-turn-current-position', position);
      turnOverlay.setAttribute('data-turn-route', state.turn.route.join('>'));
    }
  }

  function sowAlong(arrow) {
    var next = arrow.getAttribute('data-to-position');
    if (!placeOneCubeAtPosition(next)) {
      return false;
    }
    setCurrentPosition(next);
    return true;
  }

  /* The hand walks the board and puts one cube down at each position it comes to. It stops only
     at a fork: one way out is not a choice, so nothing is asked about it, and the walk runs on
     until either the hand is empty or the board asks which way.

     It also stops where there is nowhere to put the next cube -- a column with no room left, or a
     position with no way out of it. Neither should happen on this board, since every position has
     an arrow leaving it and a sow is short, but a tile only shows three cubes to a seat while the
     rules cap nothing, so a column can fill. The hand keeps what it is still holding, the counter
     goes on showing it, and `Reset` is the way out. */
  function continueSowing() {
    setTurnPhase('sowing');
    while (state.turn.cubesInHand > 0) {
      var ways = branchArrowsFrom(state.turn.current);
      if (ways.length > 1) {
        highlightBranchChoices(ways);
        setTurnPhase('branch_choice');
        return;
      }
      if (!ways.length || !sowAlong(ways[0])) {
        return;
      }
    }
    completeSowing();
  }

  /* A setup sow ends with no duty on offer: the seat was putting its acolytes out, not taking a
     duty, and what is waiting for it is `Confirm` rather than `Action` or `Tithe`. */
  function completeSowing() {
    clearBranchChoices();
    setTurnPhase('sow_complete');
    armDutyChoices(!state.setup.on);
  }

  /* The duties a finished sow leaves standing to be picked from: every tile the seat has an
     acolyte standing on, less the City, which is not a duty.

     It is read off the board rather than off the way the hand walked. A seat has acolytes out on
     the wheel before its turn begins and they are as much its own as the ones it has just sown, so
     asking where the walk went would offer it only the tiles it happened to pass and hide the rest
     of its own. Asking the board is also the whole of what makes the other three kinds of cube no
     part of the choice: another seat's, the neutral column's, and the slots nobody is standing in
     -- drawn but hidden, so not visible -- are none of them this seat's visible cubes. */
  function occupiedDutyPositions() {
    return Array.prototype.map
      .call(dutySpaces, function (space) {
        return space.getAttribute('data-board-position');
      })
      .filter(function (position) {
        return position !== cityPosition
          && visibleActivePlayerCubesForPosition(position).length > 0;
      });
  }

  function armDutyChoices(armed) {
    var eligible = armed ? occupiedDutyPositions() : [];
    Array.prototype.forEach.call(dutySpaces, function (space) {
      if (eligible.indexOf(space.getAttribute('data-board-position')) === -1) {
        space.removeAttribute('data-turn-duty-candidate');
      } else {
        space.setAttribute('data-turn-duty-candidate', 'true');
      }
    });
  }

  /* The chosen duty is marked twice over: ringed like the space the turn started from, and with
     the three lobes of its trefoil coloured in. The trefoil is drawn in a layer of its own above
     the board rather than inside the space, so the two are marked separately. */
  function markDutyChoice(position) {
    Array.prototype.forEach.call(dutySpaces, function (space) {
      space.removeAttribute('data-turn-duty-selected');
    });
    Array.prototype.forEach.call(dutyOrnaments, function (ornament) {
      ornament.removeAttribute('data-turn-duty-selected');
    });
    [spaceAt(position), ornamentAt(position)].forEach(function (node) {
      if (node) {
        node.setAttribute('data-turn-duty-selected', 'true');
      }
    });
  }

  /* What may be picked is what is on offer, and what is on offer is what `armDutyChoices` marked:
     the tiles the seat is standing on, from when the hand empties until one of them is taken.
     Nothing is ever marked during a setup sow, so nothing can be picked during one either. */
  function selectDuty(position) {
    var space = spaceAt(position);
    if (!space || space.getAttribute('data-turn-duty-candidate') !== 'true') {
      return;
    }
    state.turn.duty = position;
    markDutyChoice(position);
    if (turnOverlay) {
      turnOverlay.setAttribute('data-turn-duty', position);
    }
    setTurnPhase('duty_selected');
  }

  /* Both plaques do the one thing there is to do yet: the seat's cubes come off the duty it chose
     and go home to its City column. What either of them is actually for -- resolving the duty,
     taking the tithe -- is still to come, so all that is kept is which of them was pressed.

     A cube that finds no room in the City is left standing where it is. The City draws a seat six
     slots while the rules cap nothing, so a column can fill; a cube is only ever hidden in one
     place and shown in another, so nothing is lost either way. */
  /* What the tile lying at a board position brings with it, and null where it brings nothing.

     Two names meet here and they are not the same name. A turn moves by board position -- north,
     north_east, and so on round the ring -- while an arrangement is written against the fixed
     slots the tiles lie in, which each space carries as `data-duty`. The space is the one place
     the two are tied together, so the position is turned into a slot by asking it rather than by
     a second table that would have to be kept in step by hand.

     Asked of the arrangement on the table rather than of the board under it, because the tiles
     turn: which tile lies on a slot, and so which token it brings, changes with the setup roll. */
  function titheTokenAt(position) {
    var space = spaceAt(position);
    var slot = space ? space.getAttribute('data-duty') : null;
    if (!slot) {
      return null;
    }
    var token = null;
    DUTY.setups[state.dutySetup].forEach(function (entry) {
      if (entry.position === slot) {
        token = entry.tithe_icon;
      }
    });
    return token;
  }

  function resourceChoiceBoards() {
    return document.querySelectorAll('[data-component="player-board-v2"][data-player-seat]');
  }

  /* The Cornucopia is the one token that does not say what it pays, so the seat is asked. Its own
     board puts up the three keys; the other three boards on the table are left alone, because the
     stock being picked is this seat's and nobody else may reach for it. */
  function openTitheChoice() {
    state.turn.titheChoice = 'pending';
    Array.prototype.forEach.call(resourceChoiceBoards(), function (board) {
      var asking = Number(board.getAttribute('data-player-seat')) === state.activeSeat;
      if (asking) {
        board.setAttribute('data-resource-choice', 'true');
      } else {
        board.removeAttribute('data-resource-choice');
      }
    });
  }

  function closeTitheChoice() {
    state.turn.titheChoice = null;
    Array.prototype.forEach.call(resourceChoiceBoards(), function (board) {
      board.removeAttribute('data-resource-choice');
    });
  }

  /* Pressing a key is the payment. Guarded on the pending state rather than on the keys being up,
     so a second press cannot pay twice however it arrives. */
  function chooseTitheResource(id) {
    if (state.turn.titheChoice !== 'pending') {
      return;
    }
    var seat = state.activeSeat;
    closeTitheChoice();
    payTithe(seat, id);
    refreshTurnControls();
  }

  /* The stock moves and the turn writes down what it moved: whose, which, and how much. Written at
     the moment of payment rather than worked out again on the way back, because the tile is only
     where the amount came from and is not a record of it. Re-reading the tile at reset time would
     answer with whatever lies there then -- and the R button rewrites which duty lies where -- and
     a Cornucopia never said what it paid at all, only that the seat was asked. */
  function payTithe(seat, id) {
    creditResource(seat, id, 1);
    state.turn.paid = { seat: seat, id: id, amount: 1 };
  }

  /* And exactly that comes back off, the seat named rather than assumed. Nothing is floored on the
     way down and nothing needs to be: the only thing ever taken back here is something this same
     turn put there, so the stock cannot be walked below what the turn found. A reset with nothing
     recorded -- no tithe taken, or a Cornucopia still asking -- has nothing to take back, which is
     how a pending choice leaves the counts alone without being a case. */
  function takeTitheBack() {
    var paid = state.turn.paid;
    if (!paid) {
      return;
    }
    state.turn.paid = null;
    creditResource(paid.seat, paid.id, -paid.amount);
  }

  /* What the seat takes for the duty it chose: one of whatever that tile carries. Taxation carries
     nothing, so there is nothing to take and the plaque is dark; the Cornucopia carries the choice
     of any, so the seat is asked instead of paid. */
  function takeTithe() {
    var token = titheTokenAt(state.turn.duty);
    if (!token) {
      return;
    }
    if (token === CORNUCOPIA) {
      openTitheChoice();
    } else {
      payTithe(state.activeSeat, token);
    }
  }

  function resolveDuty(resolution) {
    if (state.turn.phase !== 'duty_selected') {
      return;
    }
    /* A tile with no token has nothing to give, so Tithe on it is not a move. The plaque is dark
       for the same reason; this is what makes the darkness mean something. */
    if (resolution === 'tithe' && !titheTokenAt(state.turn.duty)) {
      return;
    }
    var home = [];
    var sent = [];
    visibleActivePlayerCubesForPosition(state.turn.duty).forEach(function (cube) {
      var slot = firstEmptySlotForPosition(cityPosition);
      if (!slot) {
        return;
      }
      slot.setAttribute('opacity', '1');
      home.push(slot);
      sent.push(cube);
    });
    state.turn.standingInCity = home;
    state.turn.recalled = hideCubes(sent);
    state.turn.resolution = resolution;
    /* The choice is closed once the cubes are home, so the other tiles stop offering themselves. */
    armDutyChoices(false);
    if (turnOverlay) {
      turnOverlay.setAttribute('data-turn-resolution', resolution);
    }
    if (resolution === 'tithe') {
      takeTithe();
    }
    setTurnPhase('resolution_selected');
  }

  function undoRecall() {
    state.turn.standingInCity.forEach(function (slot) {
      slot.setAttribute('opacity', '0');
    });
    state.turn.standingInCity = [];
    restoreCubes(state.turn.recalled);
    state.turn.recalled = [];
  }

  /* The seat's cubes there come up into the hand and the walk begins. A space with none of them
     on it is nothing to start from, so nothing happens at all.

     A turn is asked which space to start from and a setup sow is not -- it always starts from the
     City -- so where the start comes from is the caller's business, and only the starting is
     here. For the same reason a setup sow passes `{ ring: false }`: the ring round a space is the
     answer to a question, and one that was never asked has no answer to show. What a setup is
     waiting for is a road, and the roads are lit. */
  function beginSowFrom(position, options) {
    var cubes = visibleActivePlayerCubesForPosition(position);
    if (!cubes.length) {
      return;
    }
    state.turn.start = position;
    armStartSpaces(false);
    markStartSpace(options && options.ring === false ? null : position);
    hidePickupCubes(cubes);
    setCurrentPosition(position);
    continueSowing();
  }

  /* Clicking an armed space. The click is spent either way, so the board stays armed for another
     one rather than refusing this one. */
  function selectStartSpace(position) {
    if (state.turn.phase !== 'sow_armed') {
      return;
    }
    beginSowFrom(position);
  }

  /* The way out that was asked for: one cube goes down at the far end of the arrow, and the walk
     picks up again from there. */
  function chooseRoute(arrow) {
    if (state.turn.phase !== 'branch_choice') {
      return;
    }
    if (arrow.getAttribute('data-from-position') !== state.turn.current) {
      return;
    }
    state.turn.routeChoice =
      arrow.getAttribute('data-from-position') + ':' + arrow.getAttribute('data-to-position');
    if (turnOverlay) {
      turnOverlay.setAttribute('data-last-route-choice', state.turn.routeChoice);
    }
    clearBranchChoices();
    setTurnPhase('sowing');
    if (sowAlong(arrow)) {
      continueSowing();
    }
  }

  /* Putting a turn down is two separate things, and they are kept apart because there is one
     caller -- a confirmed setup sow -- that wants the second without the first.

     Every cube goes back where the turn found it, in the order the turn moved them, last thing
     first: what the recall took home, then what the sow put down, then what the hand picked up. A
     cube can be sown into the very slot it was lifted out of and recalled out of that same slot
     again, so each layer has to hand the board back to the one beneath it before that one has its
     say. Which cubes those are is the three ledgers, and nothing else: a turn that has been
     accepted drops them, and then this moves nothing at all. */
  function putCubesBack() {
    undoRecall();
    resetSownCubes();
    restorePickupCubes();
  }

  /* And everything the turn wrote on the board about itself comes off. Not one cube is touched
     here, which is what lets an accepted setup sow be cleaned up without being undone. */
  function clearTurnMarks() {
    setCubesInHand(0);
    armStartSpaces(false);
    markStartSpace(null);
    armDutyChoices(false);
    markDutyChoice(null);
    clearBranchChoices();
    state.turn.start = null;
    state.turn.current = null;
    state.turn.route = [];
    state.turn.routeChoice = null;
    state.turn.duty = null;
    state.turn.resolution = null;
    /* An unanswered Cornucopia is taken down with the rest of the turn's marks. Nothing was paid
       while it was up, so putting it away costs the seat nothing. */
    closeTitheChoice();
    if (turnOverlay) {
      turnOverlay.removeAttribute('data-last-route-choice');
      turnOverlay.removeAttribute('data-turn-current-position');
      turnOverlay.removeAttribute('data-turn-route');
      turnOverlay.removeAttribute('data-turn-duty');
      turnOverlay.removeAttribute('data-turn-resolution');
    }
    setTurnPhase('idle');
  }

  /* Putting a turn down puts back everything it took, and a tithe is one of those things: the
     cubes go back where they were and the stock goes back to what it was, so a seat that resets is
     standing exactly where it stood before it began. */
  function resetTurnFlow() {
    takeTitheBack();
    putCubesBack();
    clearTurnMarks();
  }

  /* The seat after this one, among the seats this player count actually seats: at four, white
     hands back to red; at two, the pair alternate. That is the whole of it. Who plays first, and
     in what order the seats take their turns, is not decided here and is not decided anywhere yet
     -- the first player marker is a debug control that moves a seal and settles nothing. */
  function nextSeatedSeat(seat) {
    var seats = seatsAtTable();
    var at = seats.indexOf(seat);
    return seats[(at + 1) % seats.length];
  }

  /* The turn is over and it stands. The ledgers are dropped before anything else, so what the seat
     sowed and what it sent home stay where they are and `clearTurnMarks` has nothing left it could
     undo -- the same move an accepted setup sow makes. The paid record goes with them: from the
     next line on, Reset belongs to another seat's turn and must never reach back into this one's
     stock.

     What it does not do is write down the City column the recall has just changed. The flow owns
     what is drawn and none of what is kept, and an accepted setup sow reaches across that line
     from the other side, where `confirmSetupSow` sits. The consequence is real and is not fixed
     here: `A->C` redraws that column from the kept count, so pressing it after a turn has been
     confirmed puts the recalled cubes back where they were. */
  function endTurn() {
    if (state.setup.on || state.turn.phase !== 'resolution_selected') {
      return;
    }
    if (state.turn.titheChoice === 'pending') {
      return;
    }
    state.turn.pickedUp = [];
    state.turn.sown = [];
    state.turn.recalled = [];
    state.turn.standingInCity = [];
    state.turn.paid = null;
    clearTurnMarks();
    setActiveSeat(nextSeatedSeat(state.activeSeat));
  }

  /* A space is clicked for two different reasons at two different points in a turn: to start from
     before the sow, and to choose a duty after it. */
  Array.prototype.forEach.call(dutySpaces, function (space) {
    space.addEventListener('click', function () {
      var position = space.getAttribute('data-board-position');
      selectStartSpace(position);
      selectDuty(position);
    });
  });

  Array.prototype.forEach.call(dutyArrows, function (arrow) {
    arrow.addEventListener('click', function () {
      if (arrow.getAttribute('data-turn-branch-choice') === 'true') {
        chooseRoute(arrow);
      }
    });
  });

  if (turnControl('sow')) {
    turnControl('sow').addEventListener('click', armSow);
  }

  if (turnControl('reset')) {
    turnControl('reset').addEventListener('click', function () {
      if (state.setup.on) {
        restartSetupSow();
      } else if (state.turn.phase !== 'idle') {
        resetTurnFlow();
      }
    });
  }

  /* One plaque, two things to confirm: a setup sow while setup is on, and a finished turn the rest
     of the time. */
  if (turnControl('confirm')) {
    turnControl('confirm').addEventListener('click', function () {
      if (state.setup.on) {
        confirmSetupSow();
      } else {
        endTurn();
      }
    });
  }

  ['action', 'tithe'].forEach(function (resolution) {
    if (turnControl(resolution)) {
      turnControl(resolution).addEventListener('click', function () {
        resolveDuty(resolution);
      });
    }
  });

  /* The key is the whole pill, which is why the handler is on it and not on the icon or the
     numeral inside it: the coin is about 23 across and the amounts are set at 16. The seat is read
     off the board the key stands on rather than trusted from the state, so a key on a board that
     is not being asked cannot pay anyone even if something else reveals it. */
  Array.prototype.forEach.call(
    document.querySelectorAll('[data-resource-choice-key]'),
    function (key) {
      key.addEventListener('click', function () {
        var board = key.parentNode;
        while (board && !board.getAttribute('data-player-seat')) {
          board = board.parentNode;
        }
        if (!board || Number(board.getAttribute('data-player-seat')) !== state.activeSeat) {
          return;
        }
        chooseTitheResource(key.getAttribute('data-resource-choice-key'));
      });
    }
  );

  updateActiveSeatIndicator();
"""


def render_compact_controls_script(
    map_layout: dict,
    piety_layout: dict,
    board_layout: dict,
    alms_layout: dict,
    alms_config: dict,
    placements: list[dict],
    duty_layout: dict,
) -> str:
    """Compact local controls: player count, setup roll, discs, resources, winners, buildings,
    serfs and acolytes, the duty wheel, and the turn flow drawn on it.
    """
    buildings = json.dumps(building_control_data(board_layout, placements), separators=(",", ":"))
    duty = json.dumps(duty_control_data(duty_layout), separators=(",", ":"))
    turn_flow = render_turn_flow_script()
    return f"""<script>
(function () {{
  var VISIBLE = {json.dumps(visible_seats_by_count(), separators=(",", ":"))};
  var DEFAULT_COUNT = {DEFAULT_PLAYER_COUNT};
  var SETUP = {json.dumps(setup_roll_data(map_layout), separators=(",", ":"))};
  var DISC = {json.dumps(disc_motion_data(alms_layout, alms_config, piety_layout), separators=(",", ":"))};
  var ACOLYTES = {json.dumps(acolyte_control_data(board_layout), separators=(",", ":"))};
  var RESOURCES = {json.dumps(resource_control_data(board_layout), separators=(",", ":"))};
  var WINNERS = {json.dumps(season_winner_data(alms_layout, alms_config), separators=(",", ":"))};
  var BUILDINGS = {buildings};
  var DUTY = {duty};
  var TURN = {json.dumps(turn_flow_data(duty_layout), separators=(",", ":"))};
  var SETUP_CUBES = {SETUP_CITY_CUBES};
  var CORNUCOPIA = '{CORNUCOPIA_TOKEN}';

  function cityOpening() {{
    var opening = {{}};
    Object.keys(ACOLYTES.state).forEach(function (seat) {{
      opening[seat] = DUTY.city.opening;
    }});
    return opening;
  }}

  var state = {{
    count: DEFAULT_COUNT,
    roll: SETUP.defaultRoll,
    path: [],
    shipPosition: 0,
    discs: JSON.parse(JSON.stringify(DISC.initial)),
    acolytes: JSON.parse(JSON.stringify(ACOLYTES.state)),
    resources: JSON.parse(JSON.stringify(RESOURCES.state)),
    /* Seat numbers in slot order, so the row of sockets is just this list drawn. */
    winners: [],
    buildings: JSON.parse(JSON.stringify(BUILDINGS.state)),
    /* What each seat is standing in the City, which every column opens holding. */
    city: cityOpening(),
    dutySetup: 0,
    merchant: DUTY.merchantStart,
    /* Whose turn it is. Confirm hands it to the next seated seat; it is kept out here rather than
       inside the turn because a seat outlives any one sow. */
    activeSeat: TURN.seat,
    /* Which seat the first player marker sits with. It is always with someone, and it opens with
       seat 1 because every piety disc starts on 0 and the tie resolves to the first board. It
       decides nothing about turn order here: it moves a seal and that is all. */
    firstPlayerSeat: {FIRST_PLAYER_SEAT_AT_START},
    /* The turn drawn on the wheel: which phase it is in, where it started and where the hand
       stands now, the way it came, what is in hand, the cubes lifted off the board to put it
       there, the slots it has since stood cubes in, which way out was last picked, the duty it
       chose at the end of it, and what it chose to do there. */
    turn: {{
      phase: 'idle',
      start: null,
      current: null,
      route: [],
      cubesInHand: 0,
      pickedUp: [],
      sown: [],
      routeChoice: null,
      duty: null,
      resolution: null,
      /* Set while a Cornucopia tithe is waiting on the seat to say which stock it wants. Nothing
         has been paid at that point: the payment happens when a key is pressed, which is why a
         Reset here costs the seat nothing. */
      titheChoice: null,
      /* What a tithe on this turn actually paid -- seat, stock and amount -- so that Reset can
         take back that and nothing else. It is the turn's own receipt: it is written when the
         stock moves and torn up when the turn ends, so no Reset can ever reach a seat that has
         already handed the wheel on. */
      paid: null,
      recalled: [],
      standingInCity: []
    }},
    /* The setup sow: whether the board is dealt for one now, which seats have confirmed theirs,
       and whether one has been run through to the end since the page opened. */
    setup: {{
      on: false,
      done: [],
      finished: false
    }}
  }};

  var countButtons = document.querySelectorAll('[data-player-count-button]');
  var rollButtons = document.querySelectorAll('[data-setup-roll-button]');
  var seatBoards = document.querySelectorAll('[data-player-seat].p-player');
  var discButtons = document.querySelectorAll('[data-disc-track][data-disc-delta]');
  var discPlayerSeat = document.getElementById('disc-player-seat');
  var firstPlayerSeat = document.getElementById('first-player-seat');
  var firstPlayerSeals = document.querySelectorAll('[data-first-player-seal][data-player-seat]');
  var pietyTrack = document.querySelector('[data-first-player-seat]');
  var acolytePlayerSeat = document.getElementById('acolyte-player-seat');
  var acolyteSource = document.getElementById('acolyte-source');
  var acolyteTarget = document.getElementById('acolyte-target');
  var moveAcolyte = document.getElementById('move-acolyte');
  var serfToAbbey = document.querySelector('[data-serf-to-abbey-button]');
  var abbeyToCity = document.querySelector('[data-abbey-to-city-button]');
  var villageToCity = document.querySelector('[data-village-to-city-button]');
  var shipButton = document.querySelector('[data-ship-advance]');
  var resourceButtons = document.querySelectorAll('[data-resource-button]');
  var winnerButtons = document.querySelectorAll('[data-alms-winner-button]');
  /* Row three's dropdown is shared: it picks the seat for the winner cube and for the
     buildings alike, which is why it is not named after either. */
  var rowThreeSeat = document.getElementById('alms-winner-player-seat');
  var buildingSelect = document.getElementById('buy-building');
  var buyButton = document.querySelector('[data-building-buy-button]');
  var donateSlot = document.getElementById('donate-building-slot');
  var donateButton = document.querySelector('[data-building-donate-button]');
  var dutyRandomize = document.querySelector('[data-duty-randomize-button]');
  var setupButton = document.querySelector('[data-setup-mode-button]');
  var merchantAdvance = document.querySelector('[data-merchant-advance-button]');
  var stage = document.querySelector('.game-table-stage');
  var almsPanel = document.querySelector('.p-alms');
  var dutyPanel = document.querySelector('.p-action');
  var mapPanel = document.querySelector('.p-map');
  var setupGroups = mapPanel ? mapPanel.querySelectorAll('g[data-slot]') : [];
  var shipMarker = mapPanel ? mapPanel.querySelector('#ship-marker') : null;

  function visibleSeats(count) {{
    return VISIBLE[String(count)] || VISIBLE[String(DEFAULT_COUNT)] || [];
  }}

  function boardDiscs(track) {{
    var board = document.querySelector(track === 'alms' ? '.p-alms' : '.p-piety');
    return board ? board.querySelectorAll('[data-player-disc][data-player-seat]') : [];
  }}

  function discPoint(track, seat, position) {{
    return DISC.targets[track][String(seat)][String(position)];
  }}

  function pairPoint(track, position) {{
    return DISC.pair[track][String(position)];
  }}

  function isAlmsFirst(position) {{
    return String(position) === String(DISC.first.alms);
  }}

  function almsFirstOccupied(exceptSeat) {{
    return Object.keys(state.discs.alms).some(function (seat) {{
      return Number(seat) !== exceptSeat && isAlmsFirst(state.discs.alms[seat]);
    }});
  }}

  function nextAlmsPosition(current, delta, seat) {{
    var maximum = Number(DISC.max.alms);
    if (delta > 0) {{
      if (isAlmsFirst(current)) {{
        return DISC.first.alms;
      }}
      var step = Number(current);
      if (step < maximum) {{
        return step + 1;
      }}
      if (step === maximum && !almsFirstOccupied(seat)) {{
        return DISC.first.alms;
      }}
      return maximum;
    }}
    if (delta < 0) {{
      if (isAlmsFirst(current)) {{
        return maximum;
      }}
      return Math.max(0, Number(current) - 1);
    }}
    return current;
  }}

  function renderDiscTrack(track) {{
    var shown = visibleSeats(state.count);
    Array.prototype.forEach.call(boardDiscs(track), function (disc) {{
      var seat = Number(disc.getAttribute('data-player-seat'));
      var position = state.discs[track][String(seat)];
      var point = discPoint(track, seat, position);
      var x = point[0];
      var y = point[1];
      if (state.count === 2 && (seat === 1 || seat === 2)) {{
        var pair = pairPoint(track, position);
        x = pair[0];
        y = seat === 1 ? pair[1] : pair[2];
      }}
      disc.setAttribute('cx', Number(x).toFixed(1));
      disc.setAttribute('cy', Number(y).toFixed(1));
      disc.style.visibility = shown.indexOf(seat) === -1 ? 'hidden' : 'visible';
      disc.setAttribute(track === 'alms' ? 'data-alms-position' : 'data-piety-position', String(position));
    }});
  }}

  /* Every seat's seal is already struck into the panel, in that seat's own colour, and all but one
     are hidden. So moving the marker is showing one and hiding the rest -- exactly what
     renderDiscTrack does with the discs. Nothing here computes a colour, and nothing here may:
     the wax, the rim, the ring and the crown are all derived in the renderer, and a second
     derivation written in JavaScript would be a copy to keep in step with the first. */
  function renderFirstPlayerSeal() {{
    Array.prototype.forEach.call(firstPlayerSeals, function (seal) {{
      var seat = Number(seal.getAttribute('data-player-seat'));
      seal.style.visibility = seat === state.firstPlayerSeat ? 'visible' : 'hidden';
    }});
  }}

  function setFirstPlayerSeat(seat) {{
    state.firstPlayerSeat = seat;
    if (firstPlayerSeat) {{
      firstPlayerSeat.value = String(seat);
    }}
    /* The attribute is what names the holder, so it moves with the marker rather than staying on
       whichever seat the renderer struck it for. */
    if (pietyTrack) {{
      pietyTrack.setAttribute('data-first-player-seat', String(seat));
    }}
    renderFirstPlayerSeal();
  }}

  function moveDisc(track, delta) {{
    var seat = Number(discPlayerSeat.value);
    var key = String(seat);
    var current = state.discs[track][key];
    var next = current;
    if (track === 'alms') {{
      next = nextAlmsPosition(current, delta, seat);
    }} else {{
      var maximum = Number(DISC.max[track]);
      next = Math.max(0, Math.min(maximum, Number(current) + delta));
    }}
    state.discs[track][key] = next;
    renderDiscTrack(track);
  }}

  function renderSeatBoards() {{
    var shown = visibleSeats(state.count);
    Array.prototype.forEach.call(seatBoards, function (board) {{
      var seat = Number(board.getAttribute('data-player-seat'));
      board.style.display = shown.indexOf(seat) === -1 ? 'none' : '';
    }});
  }}

  function rotatedPath(roll) {{
    var startHex = SETUP.startHexByRoll[String(roll)];
    var offset = SETUP.edgePath.indexOf(startHex);
    return SETUP.edgePath.slice(offset).concat(SETUP.edgePath.slice(0, offset));
  }}

  function placeOnHex(element, hexLabel) {{
    var center = SETUP.hexCenters[hexLabel];
    element.setAttribute(
      'transform',
      'translate(' + Number(center[0]).toFixed(1) + ',' + Number(center[1]).toFixed(1) + ')'
    );
  }}

  function renderShip() {{
    if (shipMarker) {{
      placeOnHex(shipMarker, state.path[state.shipPosition]);
    }}
  }}

  /* One stop clockwise, wrapping at the end of the path -- the same walk the
     setup page's Advance ship button takes. There is no reset button here; a
     setup roll puts the ship back on the first stop. */
  function advanceShip() {{
    state.shipPosition = (state.shipPosition + 1) % state.path.length;
    renderShip();
  }}

  function applySetupRoll(roll) {{
    state.roll = roll;
    state.path = rotatedPath(roll);
    state.shipPosition = 0;
    Array.prototype.forEach.call(setupGroups, function (group) {{
      var slot = Number(group.getAttribute('data-slot'));
      placeOnHex(group, state.path[slot - 1]);
    }});
    /* The roll moves every overlay, including the ones a bought building left behind, so what
       is on the map is said again afterwards. */
    renderMapBuildings();
    renderShip();
    Array.prototype.forEach.call(rollButtons, function (button) {{
      var active = Number(button.getAttribute('data-setup-roll-button')) === roll;
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    }});
  }}

  function acolytesAt(playerState, place) {{
    return place === ACOLYTES.abbeyId ? playerState.abbeyAcolytes : Number(playerState.roles[place] || 0);
  }}

  function setAcolytesAt(playerState, place, count) {{
    if (place === ACOLYTES.abbeyId) {{
      playerState.abbeyAcolytes = count;
    }} else {{
      playerState.roles[place] = count;
    }}
  }}

  function capacityOf(place) {{
    return place === ACOLYTES.abbeyId ? ACOLYTES.abbeyCapacity : ACOLYTES.roleLimit;
  }}

  function show(element, visible) {{
    if (element) {{
      element.setAttribute('opacity', visible ? '1' : '0');
    }}
  }}

  function boardForSeat(seat) {{
    return document.querySelector('.p-player[data-player-seat="' + seat + '"]');
  }}

  /* A cube is a serf while it stands in the Village and an acolyte once it reaches the Abbey or a
     role circle, so both grids are drawn from the one count each holds: every slot is already on
     the board and a move is a change of opacity. */
  function renderBoardCubes(seat) {{
    var board = boardForSeat(seat);
    var playerState = state.acolytes[String(seat)];
    if (!board || !playerState) {{
      return;
    }}
    var held = {{ village: playerState.villageSerfs, abbey: playerState.abbeyAcolytes }};
    Object.keys(held).forEach(function (area) {{
      var slots = board.querySelectorAll('[data-token="' + area + '"]');
      Array.prototype.forEach.call(slots, function (slot) {{
        show(slot, Number(slot.getAttribute('data-token-index')) < held[area]);
      }});
    }});

    ACOLYTES.roles.forEach(function (role) {{
      var count = Number(playerState.roles[role] || 0);
      var roleSlots = board.querySelectorAll('[data-role="' + role + '"]');
      Array.prototype.forEach.call(roleSlots, function (slot) {{
        show(slot, count === (slot.getAttribute('data-role-slot') === 'single' ? 1 : 2));
      }});
    }});
  }}

  /* The City column a seat stands in, in every tally the wheel drew: a column is redrawn once and
     the player-count buttons then show whichever of those tallies the table is playing. */
  function renderCity(seat) {{
    var playerId = (state.acolytes[String(seat)] || {{}}).playerId;
    var standing = state.city[String(seat)];
    if (!dutyPanel || !playerId) {{
      return;
    }}
    var cubes = dutyPanel.querySelectorAll('[data-city-column-player="' + playerId + '"]');
    Array.prototype.forEach.call(cubes, function (cube) {{
      show(cube, Number(cube.getAttribute('data-city-cube')) < standing);
    }});
  }}

  /* A cube leaves the seat's board and stands in its City column. Nothing is checked but room:
     somewhere to take it from, and somewhere for it to stand. */
  function cityRoom(seat) {{
    return state.city[String(seat)] < DUTY.city.capacity;
  }}

  function sendToCity(seat, area) {{
    var playerState = state.acolytes[String(seat)];
    if (!playerState || !cityRoom(seat) || playerState[area] < 1) {{
      return;
    }}
    /* This redraws the City column, so a turn holding cubes out of it is put back first. */
    resetTurnFlow();
    playerState[area] -= 1;
    state.city[String(seat)] += 1;
    renderBoardCubes(seat);
    renderCity(seat);
    refreshBoardButtons();
  }}

  function renderResources(seat) {{
    var board = boardForSeat(seat);
    var amounts = state.resources[String(seat)];
    if (!board || !amounts) {{
      return;
    }}
    RESOURCES.ids.forEach(function (id) {{
      var readout = board.querySelector('[data-player-resource="' + id + '"]');
      if (readout) {{
        readout.textContent = String(amounts[id]);
      }}
    }});
  }}

  /* Moving a stock, said once and with the seat spelled out. Everything that pays or charges a
     player goes through here, and every caller has to name whose stock it is moving: what a turn
     hands out belongs to the seat whose turn it is, and what the debug row hands out belongs to
     whichever seat that row's dropdown is pointing at. Those are two different seats most of the
     time, and reading one where the other was meant pays the wrong player in silence. */
  function creditResource(seat, id, delta) {{
    var amounts = state.resources[String(seat)];
    if (!amounts) {{
      return;
    }}
    amounts[id] = Math.max(RESOURCES.floor, amounts[id] + delta);
    renderResources(seat);
  }}

  /* Row two's steppers, which act on that row's dropdown and not on the turn. */
  function stepResource(id, delta) {{
    creditResource(discPlayerSeat.value, id, delta);
  }}

  /* The record's sockets, drawn from `state.winners`: slot n shows the cube of whichever seat
     is nth in the list, and an empty slot shows its dashed socket back. Every cube is already
     on the board, hidden, so this only ever flips opacity. */
  function renderWinners() {{
    if (!almsPanel) {{
      return;
    }}
    for (var slot = 1; slot <= WINNERS.slotCount; slot += 1) {{
      var seat = state.winners[slot - 1];
      var cubes = almsPanel.querySelectorAll('[data-season-end-winner-slot="' + slot + '"]');
      var owner = seat ? ACOLYTES.state[String(seat)].playerId : null;
      Array.prototype.forEach.call(cubes, function (cube) {{
        show(cube, cube.getAttribute('data-player') === owner);
      }});
      /* The socket goes out from under its cube, so no dashed edge shows around it. */
      var socket = almsPanel.querySelector('[data-placeholder-slot="' + slot + '"]');
      show(socket, !owner);
    }}
  }}

  function addWinner() {{
    var seat = Number(rowThreeSeat.value);
    var playerState = state.acolytes[String(seat)];
    if (state.winners.length >= WINNERS.slotCount || playerState.abbeyAcolytes < 1) {{
      return;
    }}
    playerState.abbeyAcolytes -= 1;
    state.winners.push(seat);
    renderBoardCubes(seat);
    renderWinners();
    refreshBoardButtons();
  }}

  function resetWinners() {{
    if (!state.winners.length) {{
      return;
    }}
    var returning = state.winners.slice();
    state.winners = [];
    returning.forEach(function (seat) {{
      var playerState = state.acolytes[String(seat)];
      /* The Abbey holds what it holds: a cube coming back to a full one has nowhere to
         stand, so it is not counted twice over. */
      playerState.abbeyAcolytes = Math.min(
        ACOLYTES.abbeyCapacity, playerState.abbeyAcolytes + 1
      );
      renderBoardCubes(seat);
    }});
    renderWinners();
    refreshBoardButtons();
  }}

  /* Each player count has its own tally drawn on every space, already centred for that many
     columns, so the count only decides which of them shows. A short table plays a black neutral
     column beside the seats and a full one plays none, which is the wheel's own seeding: this
     picks a tally, it does not deal any cubes. */
  function renderDutyTallies() {{
    if (!dutyPanel) {{
      return;
    }}
    var tallies = dutyPanel.querySelectorAll('[data-cube-tally]');
    Array.prototype.forEach.call(tallies, function (tally) {{
      show(tally, tally.getAttribute('data-player-count') === String(state.count));
    }});
  }}

  /* One of the wheel's sample arrangements: the eight titles are rewritten and each space shows
     the Tithe token the tile that landed there brought with it. Taxation is the one tile with no
     Tithe token, so it is drawn without a capsule and stays where it is. */
  /* Turning the tiles changes which duty lies at a position -- its title, its Tithe token, and
     the category the space reports. Where the space stands is not the tiles' to change, so the
     board positions the arrows and the turn flow move by are left exactly as they were. */
  function renderDutySetup() {{
    if (!dutyPanel) {{
      return;
    }}
    DUTY.setups[state.dutySetup].forEach(function (entry) {{
      var space = dutyPanel.querySelector('[data-duty="' + entry.position + '"]');
      if (space) {{
        space.setAttribute('data-duty-category', entry.duty);
      }}
      var label = dutyPanel.querySelector('[data-duty-label="' + entry.position + '"]');
      if (label) {{
        label.textContent = entry.label;
      }}
      var icons = dutyPanel.querySelectorAll(
        '[data-duty-position="' + entry.position + '"][data-tithe-token]');
      Array.prototype.forEach.call(icons, function (icon) {{
        show(icon, icon.getAttribute('data-tithe-token') === entry.tithe_icon);
      }});
    }});
  }}

  function renderMerchant() {{
    if (!dutyPanel) {{
      return;
    }}
    var tokens = dutyPanel.querySelectorAll('[data-token="merchant"]');
    Array.prototype.forEach.call(tokens, function (token) {{
      show(token, token.getAttribute('data-duty-position') === state.merchant);
    }});
    var board = dutyPanel.querySelector('[data-component="duty-wheel"]');
    if (board) {{
      board.setAttribute('data-merchant-token', state.merchant);
    }}
  }}

  function randomizeDuties() {{
    state.dutySetup = (state.dutySetup + 1) % DUTY.setups.length;
    renderDutySetup();
  }}

  /* The next duty tile clockwise, wrapping round the ring. The City is not on the path. */
  function advanceMerchant() {{
    var path = DUTY.merchantPath;
    state.merchant = path[(path.indexOf(state.merchant) + 1) % path.length];
    renderMerchant();
  }}

  function buildingSlotsOf(seat) {{
    return state.buildings.players[String(seat)].buildingSlots;
  }}

  function firstEmptyBuildingSlot(seat) {{
    var slots = buildingSlotsOf(seat);
    for (var index = 0; index < slots.length; index += 1) {{
      if (slots[index] === null) {{
        return index + 1;
      }}
    }}
    return 0;
  }}

  function canDonateBuilding(seat, number) {{
    var entry = buildingSlotsOf(seat)[number - 1];
    return Boolean(entry) && !entry.donated;
  }}

  /* A bought building leaves the map: its recoloured hex and its label both go, and the map's
     own hex underneath them is untouched. What is still for sale is kept here rather than read
     off the map, so a setup roll moves the overlays around without selling anything back. */
  function renderMapBuildings() {{
    if (!mapPanel) {{
      return;
    }}
    var overlays = mapPanel.querySelectorAll(
      '#setup-fills g[data-building-id], #setup-labels g[data-building-id]');
    Array.prototype.forEach.call(overlays, function (overlay) {{
      var slot = overlay.getAttribute('data-slot');
      show(overlay, Object.prototype.hasOwnProperty.call(state.buildings.available, slot));
    }});
  }}

  /* A slot shows its building by pointing at content the page has already defined, so buying
     and donating change a reference rather than drawing anything. The dashed outline is drawn
     over that content and never moves, so a filled slot keeps the border an empty one has. */
  function renderBuildingSlots(seat) {{
    var board = boardForSeat(seat);
    if (!board) {{
      return;
    }}
    buildingSlotsOf(seat).forEach(function (entry, index) {{
      var group = board.querySelector('[data-player-board-slot="' + (index + 1) + '"]');
      if (!group) {{
        return;
      }}
      var donated = Boolean(entry) && entry.donated;
      group.setAttribute(
        'data-building-slot-state', entry === null ? 'empty' : (donated ? 'donated' : 'bought'));
      group.setAttribute('data-building-id', entry === null ? '' : entry.buildingId);
      group.setAttribute('data-setup-slot', entry === null ? '' : entry.setupSlot);
      group.setAttribute('data-donated', donated ? 'true' : 'false');
      var content = group.querySelector('[data-building-content]');
      show(content, entry !== null);
      if (entry !== null && content) {{
        content.setAttribute('href', donated ? entry.donatedContent : entry.boughtContent);
      }}
    }});
  }}

  function renderBuildings() {{
    Object.keys(state.buildings.players).forEach(function (seat) {{
      renderBuildingSlots(seat);
    }});
    renderMapBuildings();
    refreshBuildingButtons();
  }}

  function refreshBuildingButtons() {{
    var seat = Number(rowThreeSeat.value);
    buyButton.disabled = !(buildingSelect.value && firstEmptyBuildingSlot(seat));
    donateButton.disabled = !canDonateBuilding(seat, Number(donateSlot.value));
  }}

  /* Off the map and onto the first empty slot of the chosen board. Nothing is checked but the
     two things that make the move impossible: the building is gone, or the board is full. */
  function buyBuilding() {{
    var seat = Number(rowThreeSeat.value);
    var setupSlot = buildingSelect.value;
    var building = state.buildings.available[setupSlot];
    var number = firstEmptyBuildingSlot(seat);
    if (!building || !number) {{
      return;
    }}
    buildingSlotsOf(seat)[number - 1] = {{
      setupSlot: building.setupSlot,
      buildingId: building.buildingId,
      name: building.name,
      level: building.level,
      boughtContent: building.boughtContent,
      donatedContent: building.donatedContent,
      donated: false
    }};
    delete state.buildings.available[setupSlot];
    /* Sold is sold: it leaves the list it was bought from as well as the map. */
    var option = buildingSelect.querySelector('option[value="' + setupSlot + '"]');
    if (option) {{
      option.parentNode.removeChild(option);
    }}
    renderBuildings();
  }}

  /* One flip, one way: an empty slot has nothing to turn over and a donated one is already
     turned. */
  function donateBuilding() {{
    var seat = Number(rowThreeSeat.value);
    var number = Number(donateSlot.value);
    if (!canDonateBuilding(seat, number)) {{
      return;
    }}
    buildingSlotsOf(seat)[number - 1].donated = true;
    renderBuildings();
  }}

  function canMoveAcolyte() {{
    var seat = String(acolytePlayerSeat.value);
    var playerState = state.acolytes[seat];
    var source = acolyteSource.value;
    var target = acolyteTarget.value;
    return (
      source !== target &&
      acolytesAt(playerState, source) > 0 &&
      acolytesAt(playerState, target) < capacityOf(target)
    );
  }}

  /* A serf becomes an acolyte by walking to the Abbey, so the move needs a cube in the Village
     and a free slot in the Abbey -- the same pair of conditions the game setup page checks. */
  function canMoveSerf() {{
    var playerState = state.acolytes[String(acolytePlayerSeat.value)];
    return playerState.villageSerfs > 0 && playerState.abbeyAcolytes < ACOLYTES.abbeyCapacity;
  }}

  function refreshBoardButtons() {{
    var seat = String(acolytePlayerSeat.value);
    var playerState = state.acolytes[seat];
    moveAcolyte.disabled = !canMoveAcolyte();
    serfToAbbey.disabled = !canMoveSerf();
    abbeyToCity.disabled = !cityRoom(seat) || playerState.abbeyAcolytes < 1;
    villageToCity.disabled = !cityRoom(seat) || playerState.villageSerfs < 1;
  }}

  /* --- the setup sow -------------------------------------------------------------------------
     The game before the game. Every seat starts with five acolytes in the City and sows them out
     onto the wheel, one seat after another, and only when the last has finished does the first
     turn begin. The sowing is the turn flow's, unchanged: setup only deals the board for it, then
     hands it from seat to seat. What is dealt is a board to click on rather than a position in a
     game -- nothing here is worth anything until something that knows the rules is asked.

     It sits with the compact rows and not with the turn flow because it changes what they keep. A
     turn hides cubes and remembers them, so Reset can hand the board straight back; a deal is
     meant to stick, and the City count it writes is the same one `A->C` and `V->C` read. */

  /* A deal is made on the tally the table is playing and nowhere else. The wheel drew a tally for
     every count and shows one at a time, and `renderCity` writes a seat's City column in all of
     them at once -- which would leave the other three saying a seat is in the City while their own
     duty tiles still hold the cubes it sowed out of it. So the columns are stood by hand here, and
     the City count the compact rows keep is written to match what was dealt. */
  function dealSetupCubes() {{
    seatsAtTable().forEach(function (seat) {{
      var playerId = playerIdForSeat(seat);
      Array.prototype.forEach.call(dutySpaces, function (space) {{
        var position = space.getAttribute('data-board-position');
        standColumn(position, playerId, position === cityPosition ? SETUP_CUBES : 0);
      }});
      state.city[String(seat)] = SETUP_CUBES;
    }});
  }}

  /* Pressing `Setup` deals again from the top, whether or not one was already under way. */
  function enterSetupMode() {{
    resetTurnFlow();
    state.setup.on = true;
    state.setup.done = [];
    dealSetupCubes();
    setActiveSeat(1);
    startSetupSow();
    refreshSetupMode();
  }}

  /* A setup sow always starts from the City, so there is nothing to ask the seat and nothing for
     `Sow` to do: its five acolytes come up into the hand the moment the wheel reaches it, and what
     it is waiting for is the first fork -- which, starting where it starts, is immediate.

     And the City is not ringed for it. The ring marks the space a seat chose to start from, and
     this seat chose nothing; ringing it would colour in an answer to a question it was never
     asked. The two green roads out are the whole of what a setup is waiting on. */
  function startSetupSow() {{
    beginSowFrom(cityPosition, {{ ring: false }});
  }}

  /* Which seat is sowing is not written down again here: the board already rings it, and says so
     on the stage as `data-active-player-seat`. */
  function refreshSetupMode() {{
    if (setupButton) {{
      setupButton.setAttribute('aria-pressed', state.setup.on ? 'true' : 'false');
    }}
    if (stage) {{
      stage.setAttribute(
        'data-setup-mode',
        state.setup.on ? 'active' : state.setup.finished ? 'complete' : 'inactive');
      stage.setAttribute('data-setup-completed-seats', state.setup.done.join(','));
    }}
    refreshTurnControls();
  }}

  /* Where a seat put its acolytes is where they stay. So confirming moves not one cube: the sow's
     ledgers -- what it would need in order to take them back -- are dropped rather than played
     back, and only the marks the sow made about itself are cleared. The City count the compact
     rows keep is set to what the seat actually left there, which is a number in the record and not
     a redraw of the board; the board is already showing it, because the sow put it there.

     That holds for the last seat as much as for the others. All that is different about the last
     is what happens next: there is no seat to hand the wheel to, so the table goes back to the
     first to begin and setup lets go of the board exactly as it stands. */
  function confirmSetupSow() {{
    if (!state.setup.on || state.turn.phase !== 'sow_complete') {{
      return;
    }}
    var seat = state.activeSeat;
    state.setup.done.push(seat);
    state.city[String(seat)] = visibleActivePlayerCubesForPosition(cityPosition).length;
    state.turn.pickedUp = [];
    state.turn.sown = [];
    clearTurnMarks();
    var waiting = seatsAtTable().filter(function (other) {{
      return state.setup.done.indexOf(other) === -1;
    }});
    if (waiting.length) {{
      setActiveSeat(waiting[0]);
      startSetupSow();
    }} else {{
      state.setup.on = false;
      state.setup.finished = true;
      setActiveSeat(1);
    }}
    refreshSetupMode();
  }}

  /* `Reset` in setup hands the seat its five acolytes back and sets it going again from the City,
     which is the only place a setup sow starts. The seats that have already confirmed keep what
     they placed: there is nothing of theirs left to undo.

     It is also the way out of anything that has put the flow down mid-setup -- a compact row that
     redraws a City column, say -- which is why `Reset` stays lit all through a setup even when
     there is no sow standing to be put down. */
  function restartSetupSow() {{
    resetTurnFlow();
    standColumn(cityPosition, activePlayerId(), SETUP_CUBES);
    state.city[String(state.activeSeat)] = SETUP_CUBES;
    startSetupSow();
  }}

  /* A count change redraws the tallies a turn may have cubes lifted out of, so the turn is put
     back first rather than being left holding cubes the board has since redrawn. A setup deals
     again afterwards for the same reason: the tally now on the table is a different one, drawn as
     the wheel opens rather than as a setup left it, and the seats it holds are a different list. */
  function applyPlayerCount(count) {{
    resetTurnFlow();
    state.count = count;
    renderSeatBoards();
    renderDiscTrack('alms');
    renderDiscTrack('piety');
    renderDutyTallies();
    Array.prototype.forEach.call(countButtons, function (button) {{
      var active = Number(button.getAttribute('data-player-count-button')) === count;
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    }});
    /* A seat that has just left the table cannot be the one whose turn it is. */
    setActiveSeat(state.activeSeat > count ? {DEFAULT_CONTROL_PLAYER_SEAT} : state.activeSeat);
    /* Nor can it be holding the marker. It goes back to the seat it starts the game with, never
       to nobody: there is no state in which the marker is off the table. */
    setFirstPlayerSeat(
      state.firstPlayerSeat > count ? {FIRST_PLAYER_SEAT_AT_START} : state.firstPlayerSeat
    );
    if (state.setup.on) {{
      enterSetupMode();
    }} else {{
      /* The tally now on the table is one no setup has dealt, whatever was done to the last. */
      state.setup.finished = false;
      refreshSetupMode();
    }}
  }}

  Array.prototype.forEach.call(countButtons, function (button) {{
    button.addEventListener('click', function () {{
      applyPlayerCount(Number(button.getAttribute('data-player-count-button')));
    }});
  }});

  Array.prototype.forEach.call(rollButtons, function (button) {{
    button.addEventListener('click', function () {{
      applySetupRoll(Number(button.getAttribute('data-setup-roll-button')));
    }});
  }});

  if (shipButton) {{
    shipButton.addEventListener('click', advanceShip);
  }}

  if (dutyRandomize) {{
    dutyRandomize.addEventListener('click', randomizeDuties);
  }}

  if (setupButton) {{
    setupButton.addEventListener('click', enterSetupMode);
  }}

  if (merchantAdvance) {{
    merchantAdvance.addEventListener('click', advanceMerchant);
  }}

  Array.prototype.forEach.call(resourceButtons, function (button) {{
    button.addEventListener('click', function () {{
      var step = button.getAttribute('data-resource-button').split(':');
      stepResource(step[0], step[1] === '-' ? -1 : 1);
    }});
  }});

  buyButton.addEventListener('click', buyBuilding);
  donateButton.addEventListener('click', donateBuilding);

  [rowThreeSeat, buildingSelect, donateSlot].forEach(function (select) {{
    select.addEventListener('change', refreshBuildingButtons);
  }});

  Array.prototype.forEach.call(winnerButtons, function (button) {{
    button.addEventListener('click', function () {{
      if (button.getAttribute('data-alms-winner-button') === 'add') {{
        addWinner();
      }} else {{
        resetWinners();
      }}
    }});
  }});

  Array.prototype.forEach.call(discButtons, function (button) {{
    button.addEventListener('click', function () {{
      var track = button.getAttribute('data-disc-track');
      var delta = Number(button.getAttribute('data-disc-delta'));
      moveDisc(track, delta);
    }});
  }});

  moveAcolyte.addEventListener('click', function () {{
    if (!canMoveAcolyte()) {{
      return;
    }}
    var seat = String(acolytePlayerSeat.value);
    var playerState = state.acolytes[seat];
    var source = acolyteSource.value;
    var target = acolyteTarget.value;
    setAcolytesAt(playerState, source, acolytesAt(playerState, source) - 1);
    setAcolytesAt(playerState, target, acolytesAt(playerState, target) + 1);
    renderBoardCubes(seat);
    refreshBoardButtons();
  }});

  serfToAbbey.addEventListener('click', function () {{
    if (!canMoveSerf()) {{
      return;
    }}
    var seat = String(acolytePlayerSeat.value);
    var playerState = state.acolytes[seat];
    playerState.villageSerfs -= 1;
    playerState.abbeyAcolytes += 1;
    renderBoardCubes(seat);
    refreshBoardButtons();
  }});

  abbeyToCity.addEventListener('click', function () {{
    sendToCity(String(acolytePlayerSeat.value), 'abbeyAcolytes');
  }});

  villageToCity.addEventListener('click', function () {{
    sendToCity(String(acolytePlayerSeat.value), 'villageSerfs');
  }});

  [acolytePlayerSeat, acolyteSource, acolyteTarget].forEach(function (control) {{
    control.addEventListener('change', refreshBoardButtons);
  }});

  if (firstPlayerSeat) {{
    firstPlayerSeat.addEventListener('change', function () {{
      setFirstPlayerSeat(Number(firstPlayerSeat.value));
    }});
  }}

{turn_flow}
  Object.keys(state.acolytes).forEach(function (seat) {{
    renderBoardCubes(seat);
    renderResources(seat);
    renderCity(seat);
  }});
  renderWinners();
  renderBuildings();
  renderDutySetup();
  renderMerchant();
  applySetupRoll(SETUP.defaultRoll);
  applyPlayerCount(DEFAULT_COUNT);
  refreshBoardButtons();
}})();
</script>"""


# ---------------------------------------------------------------------------------------------
# The page
# ---------------------------------------------------------------------------------------------


def render_game_table_html(
    map_layout: dict,
    piety_layout: dict,
    piety_config: dict,
    catalog: dict,
    site_data: dict | list,
    board_layout: dict,
    duty_wheel_layout: dict,
    alms_layout: dict,
    alms_config: dict,
) -> str:
    content, hexes, cubes = board_measurements(
        alms_layout, piety_layout, board_layout, duty_wheel_layout, map_layout
    )
    scale = solve_table_scale(content, hexes, cubes)
    hexagon = duty_hexagon(duty_wheel_layout)

    # The `1st` pocket is painted solid, so a disc that can be moved into it has to be drawn
    # after it. That is what the renderer's interactive form is for: it lifts the discs out of
    # their step groups into one layer above the pocket. Nothing about the board's drawing
    # changes -- the four discs still start on step 0.
    alms_svg = tag_player_discs(
        crop_svg(
            render_alms_table_svg(alms_layout, alms_config, interactive=True),
            scale.crop["alms"],
        )
    )
    piety_svg = tag_player_discs(
        crop_svg(
            render_piety_track_v2_svg(
                piety_layout,
                piety_config,
                PIETY_VARIANT_ID,
                FIRST_PLAYER_SEAT_AT_START,
                interactive=True,
            ),
            scale.crop["piety"],
        )
    )
    placements = setup_placements(DEFAULT_START_ROLL, catalog, site_data)
    map_svg = crop_svg(render_setup_map_svg(map_layout, placements), scale.crop["map"])
    # Every side of every building a board slot can show, defined once and pointed at, so buying
    # or donating is a change of reference rather than SVG built in the browser.
    content_defs = render_building_content_defs(placements, load_donated_building_tiles())
    # The wheel's own controls stay off -- they would add height, and this page drives it from the
    # compact rows instead. Its interactive form is what they drive: every tally, Tithe token and
    # Merchant slot drawn hidden, so a click flips opacity rather than redrawing the board.
    duty_seated = duty_wheel_seating(duty_wheel_layout)
    duty_svg = crop_svg(
        regularise_duty_hexagon(
            render_duty_wheel_svg(
                duty_seated,
                interactive=True,
                turn_controls=True,
                city_spoke_reversals=CITY_SPOKE_REVERSAL_ARROWS,
            ),
            hexagon,
        ),
        scale.crop["action"],
    )
    panels = []
    active_color = ""
    for index, seat in enumerate(SEATED_PLAYERS, start=1):
        player = player_by_id(board_layout, seat)
        active = index == DEFAULT_CONTROL_PLAYER_SEAT
        if active:
            active_color = player["color"]
        board = tag_resource_readouts(
            render_player_board_v2_svg(
                board_layout, player, interactive=True, choice_keys=True
            ),
            board_layout,
        )
        panels.append(
            f'<div class="panel p-player" data-component="player-board-v2"'
            f' data-player-seat="{index}"'
            f' data-player="{player["id"]}" data-player-color="{player["color"]}"'
            f' data-active-seat="{str(active).lower()}">'
            f"{crop_svg(board, scale.crop['player'])}</div>"
        )
    seats = "\n      ".join(panels)
    # Whose turn it is, said once where anything on the page can read it.
    active_seat_hooks = (
        f'data-active-player-seat="{DEFAULT_CONTROL_PLAYER_SEAT}"'
        f' data-active-player-color="{active_color}"'
    )
    controls = render_compact_controls(board_layout, placements)
    stage = render_table_stage(
        alms_svg=alms_svg,
        piety_svg=piety_svg,
        duty_svg=duty_svg,
        map_svg=map_svg,
        seats=seats,
        stage_attributes=active_seat_hooks,
        under_alms=controls,
    )
    control_script = render_compact_controls_script(
        map_layout, piety_layout, board_layout, alms_layout, alms_config, placements, duty_seated
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{PAGE_TITLE}</title>
<style>
{table_layout_styles(scale)}

  .table-controls {{
    display: flex; flex-direction: column; align-items: center; gap: 4px;
  }}
  .control-row {{
    display: flex; align-items: center; justify-content: center; gap: 4px;
    flex-wrap: wrap;
  }}
  .control-row button,
  .control-row select {{
    background: #1C1C1C; border: 1px solid #4A4A4A; border-radius: 6px;
    color: #F2EEDF; font: inherit; font-size: 13px;
  }}
  .control-row button {{
    cursor: pointer; min-width: 2.55em; padding: 6px 10px;
  }}
  .control-row select {{
    min-width: 54px; padding: 5px 6px;
  }}
  .control-row button:hover {{ background: #2A2A2A; }}
  .control-row button[aria-pressed="true"] {{
    background: #F2EEDF; border-color: #F2EEDF; color: #1C1C1C;
  }}

  /* The turn flow, drawn on the wheel. The renderer draws the plaques, the spaces and the
     arrows; these say what a phase changes about them. Everything a phase touches is an
     attribute, so a click sets a word rather than restyling anything. */
  .game-table-stage {{ --active-player: {ACTIVE_PLAYER_FALLBACK}; }}
  /* Whose turn it is, said once in the seat's own colour and read here and on the wheel. The board
     says it itself, with the wash of its own colour the renderer drew up off its bottom edge and
     left hidden: a board is a thing on a table, and a ring drawn round the outside of one is a
     browser's idea of a selected thing rather than a table's. Only the showing of it is here, so
     nothing about the board moves or is restyled -- the rule turns a layer up from nothing. */
  .p-player[data-active-seat="true"] [data-active-player-glow="true"] {{ opacity: 1; }}
  [data-turn-control][data-turn-control-enabled="true"] {{ opacity: 1; cursor: pointer; }}
  [data-turn-control][data-turn-control-enabled="false"] {{ opacity: {TURN_DIMMED_OPACITY}; }}
  [data-turn-control][data-turn-control-active="true"] rect {{ fill: #F2EEDF; }}
  [data-turn-control][data-turn-control-active="true"] text {{ fill: #1C1C1C; }}
  /* A space that can be started from is outlined rather than filled: the green under a duty
     tile means the board, not a selection. */
  [data-turn-start-candidate="true"] {{ cursor: pointer; }}
  [data-turn-start-candidate="true"] .board-circle {{ stroke: #F2EEDF; stroke-width: 4; }}
  [data-turn-start-selected="true"] .board-circle {{
    stroke: var(--active-player); stroke-width: 5.5;
  }}
  /* And a duty a finished sow left standing to be picked from, in the same cream and then the
     same colour: what marks the chosen one apart from the space the turn started at is its
     trefoil, coloured in above the title. */
  [data-turn-duty-candidate="true"] {{ cursor: pointer; }}
  [data-turn-duty-candidate="true"] .board-circle {{ stroke: #F2EEDF; stroke-width: 4; }}
  [data-turn-duty-selected="true"] .board-circle {{
    stroke: var(--active-player); stroke-width: 3.5;
  }}
  /* Filled, but still outlined as it was drawn: the three lobes overlap, and without the lines
     between them a coloured trefoil is a coloured blob. */
  [data-ornament-position][data-turn-duty-selected="true"] circle {{
    fill: var(--active-player); stroke-opacity: 0.7;
  }}
  [data-turn-branch-choice="true"] {{ cursor: pointer; }}
  [data-turn-branch-choice="true"] .arrow-interior {{ fill: {TURN_BRANCH_GREEN}; }}
  [data-turn-branch-choice="true"] .arrow-border {{ stroke: {TURN_BRANCH_EDGE}; }}

  /* And the three keys a Cornucopia tithe puts up on the seat's own board. The board renderer
     draws them and this is what shows them; the rules are the renderer's too. */
{resource_choice_styles()}

{table_stacking_styles(scale)}
</style>
</head>
<body>
{stage}
  {content_defs}
  {control_script}
</body>
</html>
"""


def generate_game_table_page(
    *,
    map_layout_path: Path | None = None,
    piety_layout_path: Path | None = None,
    piety_config_path: Path | None = None,
    catalog_path: Path | None = None,
    site_data_path: Path | None = None,
    board_layout_path: Path | None = None,
    duty_wheel_layout_path: Path | None = None,
    alms_layout_path: Path | None = None,
    alms_config_path: Path | None = None,
    output_path: Path | None = None,
) -> Path:
    destination = default_output_path() if output_path is None else Path(output_path)
    html = render_game_table_html(
        load_map_layout(map_layout_path),
        load_piety_track_v2_layout(piety_layout_path),
        load_piety_config(piety_config_path),
        load_building_catalog(catalog_path),
        load_pilgrimage_sites(site_data_path),
        load_player_boards_v2_layout(board_layout_path),
        load_duty_wheel_layout(duty_wheel_layout_path),
        load_alms_table_layout(alms_layout_path),
        load_alms_config(alms_config_path),
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(html, encoding="utf-8")
    return destination


def main() -> None:
    written = generate_game_table_page()
    print(f"wrote {written}")


if __name__ == "__main__":
    main()
