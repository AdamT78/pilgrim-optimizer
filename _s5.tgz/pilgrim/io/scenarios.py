"""JSON-driven scenario loading for deterministic engine runs."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pilgrim.model.buildings import BuildingsConfig, PlayerBoardSlots
from pilgrim.model.config import GameConfig, game_config_from_dict
from pilgrim.model.dummy import DummyAcolyteGroups
from pilgrim.model.duties import DUTY_POSITIONS
from pilgrim.model.enums import EventType, PlayerId, TurnPhase
from pilgrim.model.events import GameEvent, make_event_details
from pilgrim.model.resources import Resources
from pilgrim.model.special_activities import SPECIAL_ACTIVITY_IDS, SpecialActivities
from pilgrim.model.state import GameState, PlayerState, TurnProgress
from pilgrim.model.timing import TimingState
from pilgrim.model.workforce import MANCALA_POSITION_COUNT, CommittedAcolytes, Workforce
from pilgrim.opponents import OpponentModel, opponent_model_from_dict
from pilgrim.rules.buildings import default_building_market, validate_building_state
from pilgrim.rules.dummy import seed_dummy_groups


@dataclass(frozen=True, slots=True)
class LoadedScenario:
    """Loaded scenario bundle used by CLI and tests."""

    scenario_id: str
    state: GameState
    config: GameConfig
    root_player_id: PlayerId
    opponent_model: OpponentModel


def load_scenario(path: str | Path) -> LoadedScenario:
    """Load scenario + setup + config JSON into typed models."""
    scenario_path = Path(path).resolve()
    scenario_raw = _read_json(scenario_path)
    merged = _merge_setup_into_scenario(scenario_raw, scenario_path)

    board_path = _resolve_path(str(merged["board_file"]), scenario_path)
    duties_path = _resolve_path(str(merged["duties_file"]), scenario_path)
    piety_file = str(merged.get("piety_file", "configs/piety.json"))
    piety_path = _resolve_path(piety_file, scenario_path)
    alms_file = str(merged.get("alms_file", "configs/alms.json"))
    alms_path = _resolve_path(alms_file, scenario_path)
    timing_file = str(merged.get("timing_file", "configs/timing.json"))
    timing_path = _resolve_path(timing_file, scenario_path)
    merchant_file = str(merged.get("merchant_file", "configs/merchant.json"))
    merchant_path = _resolve_path(merchant_file, scenario_path)
    ship_file = str(merged.get("ship_file", "configs/ship.json"))
    ship_path = _resolve_path(ship_file, scenario_path)
    buildings_file = merged.get("buildings_file")
    buildings_path = (
        _resolve_path(str(buildings_file), scenario_path)
        if buildings_file is not None
        else _default_buildings_path()
    )
    board_raw = _read_json(board_path)
    duties_raw = _read_json(duties_path)
    piety_raw = _read_json(piety_path)
    alms_raw = _read_json(alms_path)
    timing_raw = _read_json(timing_path)
    merchant_raw = _read_json(merchant_path)
    ship_raw = _read_json(ship_path)
    buildings_raw = _read_json(buildings_path)

    config = game_config_from_dict(
        board_raw=board_raw,
        duties_raw=duties_raw,
        piety_raw=piety_raw,
        alms_raw=alms_raw,
        timing_raw=timing_raw,
        merchant_raw=merchant_raw,
        ship_raw=ship_raw,
        buildings_raw=buildings_raw,
        duty_tiles_raw=_duty_tiles_from_dict(merged.get("duty_tiles")),
        tithe_counters_raw=_tithe_counters_from_dict(merged.get("tithe_counters")),
    )
    table_player_count = _player_count_from_dict(merged)
    state = _game_state_from_dict(
        merged["initial_state"],
        scenario_raw=merged,
        taxation_board_position=config.duty_tiles.board_index_for_category("taxation"),
        ship_start_position=config.ship.start_position,
        ship_path_length=config.ship.path_length,
        buildings_config=config.buildings,
        table_player_count=table_player_count,
    )
    validate_building_state(state, config)
    scenario_id = str(merged.get("scenario_id", merged.get("name", scenario_path.stem)))
    root_player_id = _root_player_from_dict(merged, default_player=state.active_player)
    opponent_model = _opponent_model_from_dict(merged)
    return LoadedScenario(
        scenario_id=scenario_id,
        state=state,
        config=config,
        root_player_id=root_player_id,
        opponent_model=opponent_model,
    )


def _merge_setup_into_scenario(
    scenario_raw: Mapping[str, Any],
    scenario_path: Path,
) -> dict[str, Any]:
    if "setup_file" not in scenario_raw:
        return dict(scenario_raw)
    setup_path = _resolve_path(str(scenario_raw["setup_file"]), scenario_path)
    setup_raw = _read_json(setup_path)
    merged = _deep_merge(dict(setup_raw), dict(scenario_raw))
    return merged


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(dict(merged[key]), dict(value))
        else:
            merged[key] = value
    return merged


def _game_state_from_dict(
    raw: Mapping[str, Any],
    *,
    scenario_raw: Mapping[str, Any],
    taxation_board_position: int,
    ship_start_position: int,
    ship_path_length: int,
    buildings_config: BuildingsConfig,
    table_player_count: int,
) -> GameState:
    players_raw = raw["players"]
    acolytes_raw = raw.get("acolytes")
    parsed_players = _players_from_dict(players_raw, acolytes_raw=acolytes_raw)
    player_states = tuple(player_state for _, player_state in parsed_players)
    timing = _timing_state_from_dict(raw)
    merchant_board_position = _merchant_board_position_from_dict(
        raw, taxation_board_position=taxation_board_position
    )
    ship_position = int(raw.get("ship_position", ship_start_position))
    completed_rounds = int(raw.get("completed_rounds", max(0, timing.round_number - 1)))
    start_player = _start_player_from_dict(raw)
    first_player_marker = _first_player_marker_from_dict(raw)
    game_over = bool(raw.get("game_over", False))
    confession_pending, confession_used = _start_player_confession_from_dict(raw)
    setup_sow_required, setup_sow_complete, setup_sow_completed_by = _setup_sow_state_from_dict(
        raw,
        scenario_raw=scenario_raw,
    )
    phase = _phase_from_dict(
        raw,
        setup_sow_required=setup_sow_required,
        setup_sow_complete=setup_sow_complete,
    )
    dummy_acolytes = _dummy_acolytes_from_dict(raw, table_player_count=table_player_count)
    building_market = _building_market_from_dict(raw, buildings_config)
    pilgrimage_rounds = _pilgrimage_rounds_from_dict(
        raw,
        scenario_raw=scenario_raw,
    )
    building_availability = _building_availability_from_dict(
        raw,
        building_market,
        pilgrimage_rounds=pilgrimage_rounds,
    )
    turn_progress = _turn_progress_from_dict(raw)
    if ship_position < 0 or ship_position >= ship_path_length:
        raise ValueError(
            "Scenario ship_position must be within Ship path bounds: "
            f"{ship_position} not in [0, {ship_path_length - 1}]."
        )
    return GameState(
        active_player=PlayerId.from_string(str(raw["active_player"])),
        start_player=start_player,
        first_player_marker=first_player_marker,
        phase=phase,
        players=player_states,
        timing=timing,
        table_player_count=table_player_count,
        dummy_acolytes=dummy_acolytes,
        merchant_board_position=merchant_board_position,
        ship_position=ship_position,
        completed_rounds=completed_rounds,
        game_over=game_over,
        setup_sow_required=setup_sow_required,
        setup_sow_complete=setup_sow_complete,
        setup_sow_completed_by=setup_sow_completed_by,
        start_player_confession_pending=confession_pending,
        start_player_confession_used=confession_used,
        building_market=building_market,
        building_availability=building_availability,
        pilgrimage_rounds=pilgrimage_rounds,
        turn_progress=turn_progress,
    )


def _turn_progress_from_dict(raw: Mapping[str, Any]) -> TurnProgress:
    progress_raw = raw.get("turn_progress")
    if progress_raw is None:
        return TurnProgress()
    if not isinstance(progress_raw, Mapping):
        raise ValueError("initial_state.turn_progress must be an object.")
    used_raw = progress_raw.get("used_buildings", ())
    if not isinstance(used_raw, (list, tuple)):
        raise ValueError("initial_state.turn_progress.used_buildings must be a list.")
    events_raw = progress_raw.get("events", ())
    if not isinstance(events_raw, (list, tuple)):
        raise ValueError("initial_state.turn_progress.events must be a list.")
    events: list[GameEvent] = []
    for event_raw in events_raw:
        if not isinstance(event_raw, Mapping):
            raise ValueError("initial_state.turn_progress.events entries must be objects.")
        details_raw = event_raw.get("details", {})
        if not isinstance(details_raw, Mapping):
            raise ValueError("turn progress event details must be an object.")
        events.append(
            GameEvent(
                event_type=EventType(str(event_raw["event_type"])),
                actor=PlayerId.from_string(str(event_raw["actor"])),
                action_id=str(event_raw.get("action_id", "")),
                details=make_event_details(**dict(details_raw)),
            )
        )
    return TurnProgress(
        used_buildings=frozenset(str(building_id) for building_id in used_raw),
        events=tuple(events),
    )


def _players_from_dict(
    raw: Any,
    *,
    acolytes_raw: Any,
) -> tuple[tuple[PlayerId, PlayerState], ...]:
    if not isinstance(raw, Mapping):
        raise ValueError("initial_state.players must be an object.")

    parsed: list[tuple[PlayerId, PlayerState]] = []
    for player_key, player_state_raw in raw.items():
        if not isinstance(player_state_raw, Mapping):
            raise ValueError(f"initial_state.players.{player_key} must be an object.")
        player_id = _player_id_from_any(player_key)
        parsed.append(
            (
                player_id,
                _player_state_from_dict(
                    player_state_raw,
                    legacy_mancala=_legacy_mancala_for_player(
                        acolytes_raw,
                        str(player_key),
                    ),
                ),
            )
        )

    if not parsed:
        raise ValueError("initial_state.players must include at least two players.")

    parsed.sort(key=lambda pair: int(pair[0]))
    ordered_ids = tuple(int(player_id) for player_id, _ in parsed)
    expected_ids = tuple(range(len(parsed)))
    if ordered_ids != expected_ids:
        raise ValueError(
            "initial_state.players keys must be contiguous from player_one in order "
            f"(player_one, player_two, ...). Got ids: {ordered_ids}."
        )
    if len(parsed) < 2 or len(parsed) > 4:
        raise ValueError("initial_state.players must include between 2 and 4 real players.")
    return tuple(parsed)


def _player_state_from_dict(
    raw: Mapping[str, Any],
    *,
    legacy_mancala: tuple[int, ...] | None,
) -> PlayerState:
    resources_raw = raw["resources"]
    if "workforce" in raw:
        workforce = _workforce_from_dict(raw["workforce"])
    elif legacy_mancala is not None:
        workforce = Workforce(mancala=legacy_mancala)
    else:
        workforce = Workforce(mancala=(0,) * MANCALA_POSITION_COUNT)
    return PlayerState(
        resources=Resources(
            stone=int(resources_raw.get("stone", 0)),
            silver=int(resources_raw.get("silver", 0)),
            wheat=int(resources_raw.get("wheat", 0)),
        ),
        workforce=workforce,
        piety=int(raw.get("piety", 0)),
        alms_position=int(raw.get("alms_position", 0)),
        victory_points=int(raw.get("victory_points", 0)),
        special_activities=_special_activities_from_dict(raw.get("special_activities")),
        player_board_slots=_player_board_slots_from_dict(raw.get("player_board_slots")),
        trade_routes_count=int(raw.get("trade_routes_count", 0)),
    )


def _workforce_from_dict(raw: Mapping[str, Any]) -> Workforce:
    committed_raw = raw.get("committed", {})
    if not isinstance(committed_raw, Mapping):
        raise ValueError("workforce.committed must be an object.")
    mancala_raw = raw.get("mancala", [0] * MANCALA_POSITION_COUNT)
    if not isinstance(mancala_raw, list):
        raise ValueError("workforce.mancala must be a list.")
    return Workforce(
        mancala=tuple(int(value) for value in mancala_raw),
        village=int(raw.get("village", 0)),
        abbey=int(raw.get("abbey", 0)),
        committed=CommittedAcolytes(
            roads=int(committed_raw.get("roads", 0)),
            shrines=int(committed_raw.get("shrines", 0)),
            market_ports=int(committed_raw.get("market_ports", 0)),
            pilgrimage_sites=int(committed_raw.get("pilgrimage_sites", 0)),
            alms_table=int(committed_raw.get("alms_table", 0)),
        ),
    )


def _legacy_mancala_for_player(
    acolytes_raw: Any,
    player_key: str,
) -> tuple[int, ...] | None:
    if not isinstance(acolytes_raw, Mapping):
        return None
    vector = acolytes_raw.get(player_key)
    if not isinstance(vector, list):
        return None
    return tuple(int(value) for value in vector)


def _root_player_from_dict(raw: Mapping[str, Any], *, default_player: PlayerId) -> PlayerId:
    """Parse explicit root player; fallback to initial active player."""
    root_player_raw = raw.get("root_player_id")
    if root_player_raw is None:
        return default_player
    if isinstance(root_player_raw, str):
        text = root_player_raw.strip()
        try:
            return PlayerId.from_string(text)
        except ValueError:
            try:
                return PlayerId(int(text))
            except ValueError as exc:
                raise ValueError(f"Unknown root_player_id: {root_player_raw}") from exc
    return PlayerId(int(root_player_raw))


def _start_player_confession_from_dict(
    initial_state_raw: Mapping[str, Any],
) -> tuple[tuple[PlayerId, ...], tuple[PlayerId, ...]]:
    """The Confession Box cursor, which almost every file leaves out and rightly so.

    Absent means no phase is under way, which is the truth for any state not caught mid-round-end,
    and there is nothing to derive: a file that does not say who has already answered has not
    stopped in the middle of asking.
    """
    raw = initial_state_raw.get("start_player_confession")
    if raw is None:
        return (), ()
    if not isinstance(raw, Mapping):
        raise ValueError("initial_state.start_player_confession must be an object when provided.")
    pending_raw = raw.get("pending", [])
    used_raw = raw.get("used", [])
    if not isinstance(pending_raw, list) or not isinstance(used_raw, list):
        raise ValueError("initial_state.start_player_confession pending/used must be lists.")
    return (
        tuple(_player_id_from_any(value) for value in pending_raw),
        tuple(_player_id_from_any(value) for value in used_raw),
    )


def _setup_sow_state_from_dict(
    initial_state_raw: Mapping[str, Any],
    *,
    scenario_raw: Mapping[str, Any],
) -> tuple[bool, bool, tuple[PlayerId, ...]]:
    metadata_raw = scenario_raw.get("setup_metadata")
    metadata_required = False
    if isinstance(metadata_raw, Mapping):
        metadata_required = bool(metadata_raw.get("setup_sow_required", False))

    setup_raw = initial_state_raw.get("setup")
    if setup_raw is None:
        if metadata_required:
            return True, False, ()
        return False, True, ()
    if not isinstance(setup_raw, Mapping):
        raise ValueError("initial_state.setup must be an object when provided.")

    setup_sow_required = bool(setup_raw.get("setup_sow_required", metadata_required))
    setup_sow_complete = bool(setup_raw.get("setup_sow_complete", not setup_sow_required))
    completed_raw = setup_raw.get("setup_sow_completed_by", [])
    if not isinstance(completed_raw, list):
        raise ValueError("initial_state.setup.setup_sow_completed_by must be a list.")
    completed_by = tuple(_player_id_from_any(value) for value in completed_raw)
    return setup_sow_required, setup_sow_complete, completed_by


def _phase_from_dict(
    initial_state_raw: Mapping[str, Any],
    *,
    setup_sow_required: bool,
    setup_sow_complete: bool,
) -> TurnPhase:
    phase_text = str(initial_state_raw.get("phase", TurnPhase.SOW.value))
    phase = TurnPhase.from_string(phase_text)
    # A file waiting on the First Player marker is taken at its word. The repair below exists for
    # files that leave the phase off or contradict their own setup flags, and a game that opens on
    # the start-player decision has an unfinished setup sow by definition -- so without this it
    # would be repaired into the phase after the one it is actually in.
    if phase in (TurnPhase.START_PLAYER_SELECTION, TurnPhase.START_PLAYER_CONFESSION):
        return phase
    if setup_sow_required and not setup_sow_complete:
        return TurnPhase.SETUP_SOW
    if setup_sow_required and setup_sow_complete and phase is TurnPhase.SETUP_SOW:
        return TurnPhase.SOW
    return phase


def _timing_state_from_dict(raw: Mapping[str, Any]) -> TimingState:
    timing_raw = raw.get("timing")
    if isinstance(timing_raw, Mapping):
        return TimingState(
            absolute_turn=int(timing_raw.get("absolute_turn", raw.get("turn", 0))),
            round_number=int(timing_raw.get("round_number", 1)),
            season_number=int(timing_raw.get("season_number", 1)),
            turn_in_round=int(timing_raw.get("turn_in_round", 0)),
        )
    return TimingState(
        absolute_turn=int(raw.get("turn", 0)),
        round_number=1,
        season_number=1,
        turn_in_round=0,
    )


def _merchant_board_position_from_dict(
    raw: Mapping[str, Any], *, taxation_board_position: int
) -> int:
    """Where the Merchant stands, refusing to read a pre-rename value as a board position.

    `merchant_position` used to index a six-step path in which 0 meant Taxation. A board ring
    position is a different quantity: 0 is the City and the valid range is 1..8. The two ranges
    OVERLAP -- an old value of 1 or 2 is a perfectly legal board position and would have loaded
    silently under the new meaning, quietly moving the Merchant to a different tile and, for the
    two that changed resource, altering what the scenario was testing without failing.

    So the old name is refused rather than migrated in place. A range check could not have caught
    this; only the name can.
    """
    for stale, form in (
        (raw.get("merchant_position"), "merchant_position"),
        (raw.get("merchant"), "merchant.position"),
    ):
        if stale is not None:
            raise ValueError(
                f"Scenario carries `{form}`, which indexed the Merchant's old six-step path. "
                "The Merchant now rides the eight duty tiles: rename the field to "
                "`merchant_board_position` and give it a board ring position, 1..8, where 1 is "
                "north and the City (0) is never valid."
            )
    position = int(raw.get("merchant_board_position", taxation_board_position))
    if not 1 <= position <= len(DUTY_POSITIONS):
        raise ValueError(
            "Scenario merchant_board_position must be a duty tile, 1..8; the Merchant is never "
            f"in the City. Got {position}."
        )
    return position


def _start_player_from_dict(raw: Mapping[str, Any]) -> PlayerId | None:
    """Who begins this round, or None when the state does not say yet.

    Absent and null both mean the same thing: this state carries no chosen start player. That is a
    real answer at game open, where the first decision is about who begins and no one has said yet.
    """
    start_player_raw = raw.get("start_player_id")
    if start_player_raw is None:
        return None
    if isinstance(start_player_raw, int):
        return PlayerId(start_player_raw)
    return _player_id_from_any(start_player_raw)


def _first_player_marker_from_dict(raw: Mapping[str, Any]) -> PlayerId | None:
    """Who holds the marker, or `None` for a file that does not say.

    Absent is left absent. A missing ship position has a defensible default -- where ships start --
    and this field does not: the holder was won at a round end on piety values the file has since
    moved past, so anything derived on load would be who would win it NOW, written into a field
    that means who won it THEN. Three hundred fixtures that never had a holder do not acquire one
    by being opened.
    """
    marker_raw = raw.get("first_player_marker")
    if marker_raw is None:
        return None
    return _player_id_from_any(marker_raw)


def _player_id_from_any(raw_value: Any) -> PlayerId:
    if isinstance(raw_value, int):
        return PlayerId(raw_value)
    text = str(raw_value).strip()
    try:
        return PlayerId.from_string(text)
    except ValueError:
        return PlayerId(int(text))


def _dummy_acolytes_from_dict(
    raw: Mapping[str, Any],
    *,
    table_player_count: int,
) -> DummyAcolyteGroups:
    dummy_raw = raw.get("dummy_acolytes")
    if dummy_raw is None:
        return seed_dummy_groups(table_player_count)
    if not isinstance(dummy_raw, Mapping):
        raise ValueError("dummy_acolytes must be an object with north_group/south_group.")

    north_group_raw = dummy_raw.get("north_group")
    south_group_raw = dummy_raw.get("south_group")
    if not isinstance(north_group_raw, list) or not isinstance(south_group_raw, list):
        raise ValueError("dummy_acolytes.north_group and south_group must be lists.")
    return DummyAcolyteGroups(
        north_group=tuple(int(value) for value in north_group_raw),
        south_group=tuple(int(value) for value in south_group_raw),
    )


def _building_market_from_dict(
    raw: Mapping[str, Any],
    buildings_config: BuildingsConfig,
) -> tuple[str, ...]:
    market_raw = raw.get("building_market")
    if market_raw is None:
        return default_building_market(buildings_config)
    if not isinstance(market_raw, list):
        raise ValueError("building_market must be a list of building ids.")
    return tuple(str(value) for value in market_raw)


def _building_availability_from_dict(
    raw: Mapping[str, Any],
    building_market: tuple[str, ...],
    *,
    pilgrimage_rounds: tuple[int, ...],
) -> tuple[tuple[str, int], ...]:
    """Parse or synthesize building live rounds with one building per timeline round.

    The border track has one building slot on each round and setup generation deals market
    buildings onto distinct rounds. Legacy scenarios missing `building_availability` are repaired
    to that legal shape in market order, skipping rounds already occupied by pilgrimage sites.
    """
    availability_raw = raw.get("building_availability")
    if availability_raw is None:
        blocked_rounds = set(pilgrimage_rounds)
        fallback: list[tuple[str, int]] = []
        next_round = 2
        for building_id in building_market:
            while next_round in blocked_rounds:
                next_round += 1
            fallback.append((building_id, next_round))
            next_round += 1
        return tuple(fallback)
    if not isinstance(availability_raw, Mapping):
        raise ValueError("building_availability must be an object mapping building ids to rounds.")
    entries = tuple(
        (str(building_id), int(live_round)) for building_id, live_round in availability_raw.items()
    )
    return tuple(sorted(entries))


def _pilgrimage_rounds_from_dict(
    initial_state_raw: Mapping[str, Any],
    *,
    scenario_raw: Mapping[str, Any],
) -> tuple[int, ...]:
    explicit_rounds = initial_state_raw.get("pilgrimage_rounds")
    if explicit_rounds is not None:
        return _parse_pilgrimage_rounds_mapping(explicit_rounds)

    setup_metadata = scenario_raw.get("setup_metadata")
    if not isinstance(setup_metadata, Mapping):
        return ()
    setup_timeline = setup_metadata.get("setup_timeline")
    if not isinstance(setup_timeline, Mapping):
        return ()
    metadata_rounds = setup_timeline.get("pilgrimage_rounds")
    if metadata_rounds is None:
        return ()
    return _parse_pilgrimage_rounds_mapping(metadata_rounds)


def _parse_pilgrimage_rounds_mapping(raw: Any) -> tuple[int, ...]:
    if not isinstance(raw, Mapping):
        raise ValueError("pilgrimage_rounds must be an object mapping site keys to rounds.")
    parsed_pairs: list[tuple[int, int]] = []
    for site_key, round_number in raw.items():
        site_text = str(site_key).strip().lower()
        if not site_text.startswith("site_"):
            raise ValueError("pilgrimage_rounds keys must be site identifiers like 'site_1'.")
        try:
            site_index = int(site_text.split("_", maxsplit=1)[1])
        except ValueError as exc:
            raise ValueError(
                "pilgrimage_rounds keys must be site identifiers like 'site_1'."
            ) from exc
        parsed_pairs.append((site_index, int(round_number)))

    parsed_pairs.sort(key=lambda pair: pair[0])
    return tuple(round_number for _, round_number in parsed_pairs)


def _player_board_slots_from_dict(raw: Any) -> PlayerBoardSlots:
    if raw is None:
        return PlayerBoardSlots()
    if not isinstance(raw, Mapping):
        raise ValueError("player_board_slots must be an object.")
    active_raw = raw.get("active_buildings", [])
    donated_raw = raw.get("donated_buildings", [])
    if not isinstance(active_raw, list) or not isinstance(donated_raw, list):
        raise ValueError("active_buildings and donated_buildings must be lists.")
    return PlayerBoardSlots(
        active_buildings=tuple(str(value) for value in active_raw),
        donated_buildings=tuple(str(value) for value in donated_raw),
        cardinal_favor_tiles=int(raw.get("cardinal_favor_tiles", 0)),
    )


def _special_activities_from_dict(raw: Any) -> SpecialActivities:
    if raw is None:
        return SpecialActivities()
    if isinstance(raw, list):
        counts = {str(item): 1 for item in raw}
    elif isinstance(raw, Mapping):
        counts: dict[str, int] = {}
        for key, value in raw.items():
            if isinstance(value, bool):
                counts[str(key)] = int(value)
                continue
            if isinstance(value, int):
                counts[str(key)] = value
                continue
            raise ValueError(
                "special_activities."
                f"{key} must be true/false or integer count, got {type(value).__name__}."
            )
    else:
        raise ValueError("special_activities must be an object or list.")
    if "grain" in counts and "fields" not in counts:
        counts["fields"] = int(counts["grain"])
    elif "grain" in counts and "fields" in counts:
        if int(counts["grain"]) != int(counts["fields"]):
            raise ValueError(
                "special_activities.grain alias conflicts with special_activities.fields."
            )
    counts.pop("grain", None)
    unknown_ids = set(counts) - set(SPECIAL_ACTIVITY_IDS)
    if unknown_ids:
        raise ValueError("Unknown special activity id(s): " + ", ".join(sorted(unknown_ids)) + ".")
    return SpecialActivities(
        fields=counts.get("fields", 0),
        road_engineer=counts.get("road_engineer", 0),
        stone_mason=counts.get("stone_mason", 0),
        alms_house=counts.get("alms_house", 0),
        engraver=counts.get("engraver", 0),
        vestry=counts.get("vestry", 0),
    )


def _duty_tiles_from_dict(raw: Any) -> Mapping[str, str] | None:
    if raw is None:
        return None
    if not isinstance(raw, Mapping):
        raise ValueError("duty_tiles must be an object mapping positions to categories.")
    return {str(position): str(category) for position, category in raw.items()}


def _tithe_counters_from_dict(raw: Any) -> Mapping[str, Any] | None:
    if raw is None:
        return None
    if not isinstance(raw, Mapping):
        raise ValueError("tithe_counters must be an object mapping positions to resources/null.")
    return {str(position): resource for position, resource in raw.items()}


def _player_count_from_dict(raw: Mapping[str, Any]) -> int:
    player_count_raw = raw.get("player_count")
    if player_count_raw is None:
        initial_state_raw = raw.get("initial_state")
        if isinstance(initial_state_raw, Mapping):
            players_raw = initial_state_raw.get("players")
            if isinstance(players_raw, Mapping):
                inferred = len(players_raw)
                if inferred in (2, 3, 4):
                    return inferred
        return 2
    parsed = int(player_count_raw)
    if parsed not in (2, 3, 4):
        raise ValueError("player_count must be one of: 2, 3, 4.")
    return parsed


def _opponent_model_from_dict(raw: Mapping[str, Any]) -> OpponentModel:
    opponent_raw = raw.get("opponent_model")
    if opponent_raw is None:
        return opponent_model_from_dict(None)
    if not isinstance(opponent_raw, Mapping):
        raise ValueError("Scenario 'opponent_model' must be an object.")
    return opponent_model_from_dict(opponent_raw)


def _resolve_path(path_value: str, scenario_path: Path) -> Path:
    path = Path(path_value)
    if path.is_absolute():
        return path
    local_candidate = (scenario_path.parent / path).resolve()
    if local_candidate.exists():
        return local_candidate
    return (scenario_path.parent.parent / path).resolve()


def _default_buildings_path() -> Path:
    return (Path(__file__).resolve().parents[2] / "configs" / "buildings.json").resolve()


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return data
